#ifndef BOARD_H
#define BOARD_H

#include <esp_system.h>
#include <cJSON.h>
#include <http.h>
#include <mqtt.h>
#include <network_interface.h>
#include <udp.h>
#include <web_socket.h>
#include <functional>
#include <string>

#include "assets.h"
#include "backlight.h"
#include "camera.h"
#include "led/led.h"

/**
 * Network events for unified callback
 */
enum class NetworkEvent {
    Scanning,             // Network is scanning (WiFi scanning, etc.)
    Connecting,           // Network is connecting (data: SSID/network name)
    Connected,            // Network connected successfully (data: SSID/network name)
    Disconnected,         // Network disconnected
    WifiConfigModeEnter,  // Entered WiFi configuration mode
    WifiConfigModeExit,   // Exited WiFi configuration mode
    // Cellular modem specific events
    ModemDetecting,        // Detecting modem (baud rate, module type)
    ModemErrorNoSim,       // No SIM card detected
    ModemErrorRegDenied,   // Network registration denied
    ModemErrorInitFailed,  // Modem initialization failed
    ModemErrorTimeout      // Operation timeout
};

// Power save level enumeration
enum class PowerSaveLevel {
    LOW_POWER,    // Maximum power saving (lowest power consumption)
    BALANCED,     // Medium power saving (balanced)
    PERFORMANCE,  // No power saving (maximum power consumption / full performance)
};

// Network event callback type (event, data)
// data contains additional info like SSID for Connecting/Connected events
using NetworkEventCallback = std::function<void(NetworkEvent event, const std::string& data)>;

void* create_board();
class AudioCodec;
class Display;
class Board {
private:
    Board(const Board&) = delete;             // 禁用拷贝构造函数
    Board& operator=(const Board&) = delete;  // 禁用赋值操作

protected:
    Board();
    std::string GenerateUuid();

    // The "system" block of GetDeviceStatusJson. Shared, so the answer does not depend
    // on which network stack a board happens to be built on.
    void AddSystemStatus(cJSON* root);

    // 软件生成的设备唯一标识
    std::string uuid_;

public:
    static Board& GetInstance() {
        static Board* instance = static_cast<Board*>(create_board());
        return *instance;
    }

    virtual ~Board() = default;
    virtual std::string GetBoardType() = 0;
    virtual const char* GetStartupGreeting() { return nullptr; }
    virtual void OnAssistantSpeechStarted() {}
    virtual void OnAssistantSpeechPlaybackDrained() {}
    virtual void OnAssistantActivityChanged(bool active) { (void)active; }
    virtual void OnLocalMediaPlaybackChanged(bool active) { (void)active; }
    virtual void OnNetworkConnected() {}
    virtual std::string GetUuid() { return uuid_; }
    virtual Backlight* GetBacklight() { return nullptr; }
    virtual Led* GetLed();
    virtual AudioCodec* GetAudioCodec() = 0;
    virtual int GetOutputVolume();
    virtual void SetOutputVolume(int volume);
    virtual bool UsesPerTaskOutputVolume() const { return false; }
    virtual bool GetTemperature(float& esp32temp);
    virtual Display* GetDisplay();
    virtual Camera* GetCamera();
    virtual NetworkInterface* GetNetwork() = 0;
    virtual void StartNetwork() = 0;
    virtual void SetNetworkEventCallback(NetworkEventCallback callback) { (void)callback; }
    virtual const char* GetNetworkStateIcon() = 0;
    virtual bool GetBatteryLevel(int& level, bool& charging, bool& discharging);
    virtual std::string GetSystemInfoJson();
    static const char* ResetReasonName(esp_reset_reason_t reason);
    virtual void SetPowerSaveLevel(PowerSaveLevel level) = 0;
    virtual std::string GetBoardJson() = 0;
    virtual std::string GetDeviceStatusJson() = 0;
};

#define DECLARE_BOARD(BOARD_CLASS_NAME) \
    void* create_board() { return new BOARD_CLASS_NAME(); }

#endif  // BOARD_H
