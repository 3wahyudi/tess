#include "application.h"
#include "audio/navidrome_player.h"
#include "board.h"
#include "button.h"
#include "codecs/no_audio_codec.h"
#include "config.h"
#include "display/oled_display.h"
#include "http.h"
#include "mcp_server.h"
#include "sdkconfig.h"
#include "wifi_board.h"

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <driver/i2c_master.h>
#include <esp_http_server.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>
#include <esp_log.h>
#include <cJSON.h>
#include <nvs.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

static const char* TAG = "BabuAiBoard";

class BabuAiBoard : public WifiBoard {
private:
    i2c_master_bus_handle_t display_i2c_bus_ = nullptr;
    esp_lcd_panel_io_handle_t display_panel_io_ = nullptr;
    esp_lcd_panel_handle_t display_panel_ = nullptr;
    Display* display_ = nullptr;
    httpd_handle_t control_server_ = nullptr;
    Button boot_button_;
#if CONFIG_BABU_AI_PROFILE_ENHANCED
    Button play_pause_button_;
    Button random_next_button_;
#endif
    std::unique_ptr<NavidromePlayer> navidrome_player_;
    static constexpr std::array<int, 14> kRelayPins = {
        8, 9, 10, 13, 14, 17, 18, 21, 38, 39, 40, 41, 42, 47,
    };
    static constexpr size_t kRelayCount = kRelayPins.size();
    struct RelayConfig {
        gpio_num_t pin;
        bool active_low;
        bool on;
    };
    static constexpr std::array<RelayConfig, kRelayCount> EmptyRelayConfigs() {
        std::array<RelayConfig, kRelayCount> relays{};
        for (auto& relay : relays) {
            relay = {GPIO_NUM_NC, true, false};
        }
        return relays;
    }
    std::array<RelayConfig, kRelayCount> relays_ = EmptyRelayConfigs();
    std::array<std::string, kRelayCount> relay_names_{};
    std::mutex relay_mutex_;
    std::mutex volume_mutex_;
    int ai_volume_ = 70;
    int music_volume_ = 60;
    std::once_flag volume_settings_once_;
    mutable std::mutex target_mutex_;
    std::string music_target_ = "esp32";
    std::string stb_url_ = "http://192.168.2.115:8097/stb-api";
    TaskHandle_t stb_status_task_ = nullptr;

    static constexpr size_t kMaxStbUrlLength = 128;
    static constexpr size_t kMaxStbResponseSize = 16 * 1024;
    static constexpr int kStbHttpTimeoutMs = 6000;
    static constexpr int kStbStatusTimeoutMs = 2000;
    static constexpr char kDefaultStbUrl[] = "http://192.168.2.115:8097/stb-api";

    static std::string NormalizeStbUrl(std::string url) {
        while (!url.empty() && url.back() == '/') {
            url.pop_back();
        }
        if (url == "http://alofficial.local:8095" ||
            url == "http://192.168.2.115:8095") {
            return kDefaultStbUrl;
        }
        return url;
    }

    static bool IsValidStbUrl(const std::string& url) {
        if (url.empty() || url.size() > kMaxStbUrlLength ||
            (url.compare(0, 7, "http://") != 0 && url.compare(0, 8, "https://") != 0) ||
            url.find_first_of("?#@") != std::string::npos) {
            return false;
        }
        if (std::any_of(url.begin(), url.end(),
                        [](unsigned char character) { return std::isspace(character); })) {
            return false;
        }
        const size_t authority_start = url.compare(0, 7, "http://") == 0 ? 7 : 8;
        const size_t path_start = url.find('/', authority_start);
        const std::string authority = url.substr(
            authority_start, path_start == std::string::npos ? std::string::npos
                                                              : path_start - authority_start);
        if (authority.empty()) {
            return false;
        }
        if (path_start != std::string::npos && url.substr(path_start) != "/stb-api") {
            return false;
        }
        return true;
    }

    std::pair<std::string, std::string> GetTargetSettings() const {
        std::lock_guard<std::mutex> lock(target_mutex_);
        return {music_target_, stb_url_};
    }

    bool IsStbTarget() const {
        std::lock_guard<std::mutex> lock(target_mutex_);
        return music_target_ == "stb";
    }

    static bool IsAllowedRelayPin(int pin) {
        return std::find(kRelayPins.begin(), kRelayPins.end(), pin) != kRelayPins.end();
    }

    void LoadVolumeSettings() {
        int ai_volume = GetAudioCodec()->output_volume();
        int music_volume = 60;
        nvs_handle_t handle;
        if (nvs_open("babu-audio", NVS_READWRITE, &handle) == ESP_OK) {
            uint8_t stored = 0;
            const bool has_ai = nvs_get_u8(handle, "ai_vol", &stored) == ESP_OK;
            if (has_ai)
                ai_volume = stored;
            const bool has_music = nvs_get_u8(handle, "music_vol", &stored) == ESP_OK;
            if (has_music)
                music_volume = stored;
            if (!has_ai)
                nvs_set_u8(handle, "ai_vol", static_cast<uint8_t>(ai_volume));
            if (!has_music)
                nvs_set_u8(handle, "music_vol", static_cast<uint8_t>(music_volume));

            size_t str_len = 0;
            if (nvs_get_str(handle, "m_target", nullptr, &str_len) == ESP_OK && str_len > 1 &&
                str_len <= 16) {
                std::string target(str_len - 1, '\0');
                if (nvs_get_str(handle, "m_target", target.data(), &str_len) == ESP_OK) {
                    if (target == "esp32" || target == "stb") {
                        std::lock_guard<std::mutex> lock(target_mutex_);
                        music_target_ = target;
                    } else {
                        ESP_LOGW(TAG, "Target musik NVS tidak valid; memakai ESP32");
                    }
                }
            }
            str_len = 0;
            if (nvs_get_str(handle, "stb_url", nullptr, &str_len) == ESP_OK && str_len > 1 &&
                str_len <= kMaxStbUrlLength) {
                std::string url(str_len - 1, '\0');
                if (nvs_get_str(handle, "stb_url", url.data(), &str_len) == ESP_OK) {
                    url = NormalizeStbUrl(std::move(url));
                    if (IsValidStbUrl(url)) {
                        std::lock_guard<std::mutex> lock(target_mutex_);
                        stb_url_ = url;
                        if (nvs_get_str(handle, "stb_url", nullptr, &str_len) == ESP_OK) {
                            std::string stored_url(str_len - 1, '\0');
                            if (nvs_get_str(handle, "stb_url", stored_url.data(), &str_len) ==
                                    ESP_OK &&
                                stored_url != url) {
                                nvs_set_str(handle, "stb_url", url.c_str());
                            }
                        }
                    } else {
                        ESP_LOGW(TAG, "URL STB di NVS tidak valid; memakai proxy lokal");
                    }
                }
            }

            nvs_commit(handle);
            nvs_close(handle);
        }
        {
            std::lock_guard<std::mutex> lock(volume_mutex_);
            ai_volume_ = std::clamp(ai_volume, 0, 100);
            music_volume_ = std::clamp(music_volume, 0, 100);
        }
        if (navidrome_player_ != nullptr)
            navidrome_player_->SetMusicVolume(music_volume);
    }

    void LoadNavidromeSettings() {
        std::string url = CONFIG_BABU_AI_NAVIDROME_URL;
        std::string user = CONFIG_BABU_AI_NAVIDROME_USERNAME;
        std::string pass = CONFIG_BABU_AI_NAVIDROME_PASSWORD;
        nvs_handle_t handle;
        if (nvs_open("babu-navi", NVS_READONLY, &handle) == ESP_OK) {
            size_t len = 0;
            if (nvs_get_str(handle, "url", nullptr, &len) == ESP_OK && len > 1 && len <= 128) {
                std::string s(len - 1, '\0');
                if (nvs_get_str(handle, "url", s.data(), &len) == ESP_OK)
                    url = s;
            }
            len = 0;
            if (nvs_get_str(handle, "user", nullptr, &len) == ESP_OK && len > 1 && len <= 64) {
                std::string s(len - 1, '\0');
                if (nvs_get_str(handle, "user", s.data(), &len) == ESP_OK)
                    user = s;
            }
            len = 0;
            if (nvs_get_str(handle, "pass", nullptr, &len) == ESP_OK && len > 1 && len <= 64) {
                std::string s(len - 1, '\0');
                if (nvs_get_str(handle, "pass", s.data(), &len) == ESP_OK)
                    pass = s;
            }
            nvs_close(handle);
        }
        if (navidrome_player_ != nullptr) {
            navidrome_player_->UpdateConfig(url, user, pass);
        }
    }

    void SaveNavidromeSettings(const std::string& url, const std::string& user,
                                const std::string& pass) {
        nvs_handle_t handle;
        if (nvs_open("babu-navi", NVS_READWRITE, &handle) == ESP_OK) {
            nvs_set_str(handle, "url", url.c_str());
            nvs_set_str(handle, "user", user.c_str());
            if (!pass.empty()) {
                nvs_set_str(handle, "pass", pass.c_str());
            }
            nvs_commit(handle);
            nvs_close(handle);
        }
        std::string current_pass = pass;
        if (current_pass.empty() && navidrome_player_ != nullptr) {
            // retain previous password if omitted
            if (nvs_open("babu-navi", NVS_READONLY, &handle) == ESP_OK) {
                size_t len = 0;
                if (nvs_get_str(handle, "pass", nullptr, &len) == ESP_OK && len > 1) {
                    current_pass.resize(len - 1);
                    nvs_get_str(handle, "pass", current_pass.data(), &len);
                }
                nvs_close(handle);
            }
        }
        if (navidrome_player_ != nullptr) {
            navidrome_player_->UpdateConfig(url, user, current_pass);
        }
    }

    bool SaveTargetSettings(const std::string& target, const std::string& stb_url) {
        if (target != "esp32" && target != "stb") {
            return false;
        }
        const std::string normalized_url = NormalizeStbUrl(stb_url);
        if (!IsValidStbUrl(normalized_url)) {
            return false;
        }
        nvs_handle_t handle;
        if (nvs_open("babu-audio", NVS_READWRITE, &handle) != ESP_OK) {
            ESP_LOGE(TAG, "Tidak dapat membuka NVS untuk menyimpan target musik");
            return false;
        }
        esp_err_t result = nvs_set_str(handle, "m_target", target.c_str());
        if (result == ESP_OK) {
            result = nvs_set_str(handle, "stb_url", normalized_url.c_str());
        }
        if (result == ESP_OK) {
            result = nvs_commit(handle);
        }
        nvs_close(handle);
        if (result != ESP_OK) {
            ESP_LOGE(TAG, "Gagal menyimpan target musik ke NVS: %s", esp_err_to_name(result));
            return false;
        }

        const bool switching_to_stb = target == "stb" && !IsStbTarget();
        if (switching_to_stb && navidrome_player_ != nullptr) {
            navidrome_player_->Stop();
        }
        {
            std::lock_guard<std::mutex> lock(target_mutex_);
            music_target_ = target;
            stb_url_ = normalized_url;
        }
        return true;
    }

    static std::string UrlEncode(std::string_view value) {
        static constexpr char kHex[] = "0123456789ABCDEF";
        std::string encoded;
        encoded.reserve(value.size());
        for (unsigned char character : value) {
            if ((character >= 'a' && character <= 'z') ||
                (character >= 'A' && character <= 'Z') ||
                (character >= '0' && character <= '9') || character == '-' || character == '_' ||
                character == '.' || character == '~') {
                encoded.push_back(static_cast<char>(character));
            } else {
                encoded.push_back('%');
                encoded.push_back(kHex[character >> 4]);
                encoded.push_back(kHex[character & 0x0F]);
            }
        }
        return encoded;
    }

    static bool ReadStbResponse(Http& http, std::string& response, std::string& error) {
        std::array<char, 512> buffer{};
        response.clear();
        while (true) {
            auto size = http.Read(buffer.data(), buffer.size());
            if (!size) {
                error = size.error().ToString();
                return false;
            }
            if (*size < 0 || static_cast<size_t>(*size) > buffer.size()) {
                error = "Ukuran respons STB tidak valid";
                return false;
            }
            if (*size == 0) {
                return true;
            }
            if (static_cast<size_t>(*size) > kMaxStbResponseSize - response.size()) {
                error = "Respons STB melebihi batas ukuran";
                return false;
            }
            response.append(buffer.data(), static_cast<size_t>(*size));
        }
    }

    bool StbHttpRequest(const char* method, const std::string& path, std::string body,
                        std::string& response, std::string& error,
                        int timeout_ms = kStbHttpTimeoutMs) {
        const auto settings = GetTargetSettings();
        if (!IsValidStbUrl(settings.second)) {
            error = "URL proxy STB belum valid";
            return false;
        }
        auto* network = Board::GetInstance().GetNetwork();
        if (network == nullptr) {
            error = "Antarmuka jaringan ESP32 belum tersedia";
            return false;
        }
        auto http = network->CreateHttp(0);
        if (!http) {
            error = "Klien HTTP STB tidak dapat dibuat";
            return false;
        }

        http->SetTimeout(timeout_ms);
        http->SetHeader("Accept", "application/json");
        if (std::strcmp(method, "POST") == 0) {
            http->SetHeader("Content-Type", "application/json");
            http->SetContent(std::move(body));
        }
        std::string url = settings.second + path;
        auto opened = http->Open(method, url);
        if (!opened) {
            error = opened.error().ToString();
            http->Close();
            return false;
        }
        auto status = http->GetStatusCode();
        if (!status) {
            error = status.error().ToString();
            http->Close();
            return false;
        }
        if (!ReadStbResponse(*http, response, error)) {
            http->Close();
            return false;
        }
        http->Close();
        if (*status < 200 || *status >= 300) {
            error = "STB menolak permintaan (HTTP " + std::to_string(*status) + ")";
            return false;
        }
        return true;
    }

    static std::string JsonString(const cJSON* object, const char* key) {
        const cJSON* value = cJSON_GetObjectItemCaseSensitive(object, key);
        return cJSON_IsString(value) && value->valuestring != nullptr ? value->valuestring : "";
    }

    static bool IsValidSongId(const std::string& id) {
        return !id.empty() && id.size() <= 96 &&
               std::all_of(id.begin(), id.end(), [](unsigned char character) {
                   return (character >= 'a' && character <= 'z') ||
                          (character >= 'A' && character <= 'Z') ||
                          (character >= '0' && character <= '9') || character == '_' ||
                          character == '-';
               });
    }

    bool PostStbMusicAction(const cJSON* source, std::string& message) {
        std::string action = JsonString(source, "action");
        if (action == "volume") {
            action = "music_volume";
        }
        static constexpr std::array<std::string_view, 9> kAllowedActions = {
            "play_search", "play_id", "random", "toggle", "next",
            "previous",    "music_volume", "seek", "stop",
        };
        if (std::find(kAllowedActions.begin(), kAllowedActions.end(), action) ==
            kAllowedActions.end()) {
            message = "Aksi musik STB tidak diizinkan";
            return false;
        }

        cJSON* payload = cJSON_CreateObject();
        if (payload == nullptr) {
            message = "Memori tidak cukup untuk membuat perintah STB";
            return false;
        }
        if (cJSON_AddStringToObject(payload, "action", action.c_str()) == nullptr) {
            cJSON_Delete(payload);
            message = "Memori tidak cukup untuk menyusun perintah STB";
            return false;
        }
        if (action == "play_search") {
            const std::string query = JsonString(source, "query").empty()
                                          ? JsonString(source, "q")
                                          : JsonString(source, "query");
            if (query.empty() || query.size() > 120) {
                cJSON_Delete(payload);
                message = "Judul atau penyanyi tidak valid";
                return false;
            }
            if (cJSON_AddStringToObject(payload, "query", query.c_str()) == nullptr) {
                cJSON_Delete(payload);
                message = "Memori tidak cukup untuk menyusun pencarian STB";
                return false;
            }
        } else if (action == "play_id") {
            const std::string id = JsonString(source, "id");
            const std::string title = JsonString(source, "title");
            if (!IsValidSongId(id) || title.size() > 160) {
                cJSON_Delete(payload);
                message = "ID atau judul lagu tidak valid";
                return false;
            }
            if (cJSON_AddStringToObject(payload, "id", id.c_str()) == nullptr ||
                cJSON_AddStringToObject(payload, "title", title.c_str()) == nullptr) {
                cJSON_Delete(payload);
                message = "Memori tidak cukup untuk menyusun perintah lagu STB";
                return false;
            }
            const cJSON* queue = cJSON_GetObjectItemCaseSensitive(source, "queue");
            if (queue != nullptr) {
                if (!cJSON_IsArray(queue) || cJSON_GetArraySize(queue) > 50) {
                    cJSON_Delete(payload);
                    message = "Antrean lagu tidak valid";
                    return false;
                }
                cJSON* safe_queue = cJSON_CreateArray();
                if (safe_queue == nullptr) {
                    cJSON_Delete(payload);
                    message = "Memori tidak cukup untuk menyalin antrean";
                    return false;
                }
                const cJSON* item = nullptr;
                cJSON_ArrayForEach(item, queue) {
                    if (!cJSON_IsString(item) || item->valuestring == nullptr ||
                        !IsValidSongId(item->valuestring)) {
                        cJSON_Delete(safe_queue);
                        cJSON_Delete(payload);
                        message = "ID lagu dalam antrean tidak valid";
                        return false;
                    }
                    cJSON* song_id = cJSON_CreateString(item->valuestring);
                    if (song_id == nullptr || !cJSON_AddItemToArray(safe_queue, song_id)) {
                        cJSON_Delete(song_id);
                        cJSON_Delete(safe_queue);
                        cJSON_Delete(payload);
                        message = "Memori tidak cukup untuk menyalin antrean";
                        return false;
                    }
                }
                if (!cJSON_AddItemToObject(payload, "queue", safe_queue)) {
                    cJSON_Delete(safe_queue);
                    cJSON_Delete(payload);
                    message = "Memori tidak cukup untuk menyusun antrean STB";
                    return false;
                }
            }
        } else if (action == "music_volume") {
            const cJSON* volume = cJSON_GetObjectItemCaseSensitive(source, "volume");
            if (!cJSON_IsNumber(volume) || !std::isfinite(volume->valuedouble)) {
                cJSON_Delete(payload);
                message = "Volume musik tidak valid";
                return false;
            }
            if (cJSON_AddNumberToObject(
                    payload, "volume",
                    static_cast<int>(std::clamp(volume->valuedouble, 0.0, 100.0))) == nullptr) {
                cJSON_Delete(payload);
                message = "Memori tidak cukup untuk menyusun volume STB";
                return false;
            }
        } else if (action == "seek") {
            const cJSON* position = cJSON_GetObjectItemCaseSensitive(source, "position");
            if (!cJSON_IsNumber(position) || !std::isfinite(position->valuedouble) ||
                position->valuedouble < 0) {
                cJSON_Delete(payload);
                message = "Posisi lagu tidak valid";
                return false;
            }
            if (cJSON_AddNumberToObject(payload, "position", position->valuedouble) == nullptr) {
                cJSON_Delete(payload);
                message = "Memori tidak cukup untuk menyusun posisi lagu STB";
                return false;
            }
        }

        char* serialized = cJSON_PrintUnformatted(payload);
        cJSON_Delete(payload);
        if (serialized == nullptr) {
            message = "Gagal menyusun perintah musik STB";
            return false;
        }
        std::string response;
        std::string error;
        const bool sent =
            StbHttpRequest("POST", "/music/action", std::string(serialized), response, error);
        cJSON_free(serialized);
        if (!sent) {
            message = "STB tidak dapat menjalankan musik: " + error;
            ESP_LOGW(TAG, "%s", message.c_str());
            return false;
        }

        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> result(cJSON_Parse(response.c_str()),
                                                               cJSON_Delete);
        if (!result || !cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(result.get(), "ok"))) {
            message = result ? JsonString(result.get(), "message") : "";
            if (message.empty() && result) {
                message = JsonString(result.get(), "error");
            }
            if (message.empty()) {
                message = "Respons aksi musik STB tidak valid";
            }
            return false;
        }
        message = JsonString(result.get(), "message");
        if (message.empty()) {
            message = "Perintah musik STB diterima";
        }
        return true;
    }

    bool SetTargetMusicVolume(int volume, std::string& message) {
        const int clamped = std::clamp(volume, 0, 100);
        if (IsStbTarget()) {
            cJSON* payload = cJSON_CreateObject();
            if (payload == nullptr) {
                message = "Memori tidak cukup untuk mengatur volume STB";
                return false;
            }
            if (cJSON_AddStringToObject(payload, "action", "music_volume") == nullptr ||
                cJSON_AddNumberToObject(payload, "volume", clamped) == nullptr) {
                cJSON_Delete(payload);
                message = "Memori tidak cukup untuk menyusun volume STB";
                return false;
            }
            const bool sent = PostStbMusicAction(payload, message);
            cJSON_Delete(payload);
            if (!sent) {
                return false;
            }
        }
        SetMusicVolume(clamped);
        message = "Volume musik diatur ke " + std::to_string(clamped) + "%";
        return true;
    }

    bool SendStbMusicAction(const char* action, const char* key, const char* value,
                            std::string& message) {
        cJSON* payload = cJSON_CreateObject();
        if (payload == nullptr) {
            message = "Memori tidak cukup untuk membuat perintah STB";
            return false;
        }
        if (cJSON_AddStringToObject(payload, "action", action) == nullptr ||
            (key != nullptr && value != nullptr &&
             cJSON_AddStringToObject(payload, key, value) == nullptr)) {
            cJSON_Delete(payload);
            message = "Memori tidak cukup untuk menyusun perintah STB";
            return false;
        }
        const bool result = PostStbMusicAction(payload, message);
        cJSON_Delete(payload);
        return result;
    }

    bool GetStbJson(const std::string& path, std::string& response, std::string& error,
                    int timeout_ms = kStbHttpTimeoutMs) {
        return StbHttpRequest("GET", path, {}, response, error, timeout_ms);
    }

    std::string FormatStbSongs(const std::string& path, std::string& error) {
        std::string response;
        if (!GetStbJson(path, response, error)) {
            return {};
        }
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(cJSON_Parse(response.c_str()),
                                                             cJSON_Delete);
        const cJSON* songs = root ? cJSON_GetObjectItemCaseSensitive(root.get(), "songs") : nullptr;
        if (!cJSON_IsArray(songs)) {
            error = "Respons daftar lagu STB tidak valid";
            return {};
        }
        std::string result;
        const int count = std::min(cJSON_GetArraySize(songs), 5);
        for (int index = 0; index < count; ++index) {
            const cJSON* song = cJSON_GetArrayItem(songs, index);
            const std::string title = JsonString(song, "title");
            const std::string artist = JsonString(song, "artist");
            if (title.empty()) {
                continue;
            }
            if (!result.empty()) {
                result += "\n";
            }
            result += std::to_string(index + 1) + ". " + title;
            if (!artist.empty()) {
                result += " — " + artist;
            }
        }
        if (result.empty()) {
            error = "Tidak ada lagu yang ditemukan di Navidrome";
        }
        return result;
    }

    std::string GetStbMusicStatus(std::string& error, int timeout_ms = kStbHttpTimeoutMs) {
        std::string response;
        if (!GetStbJson("/music/status", response, error, timeout_ms)) {
            return {};
        }
        std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(cJSON_Parse(response.c_str()),
                                                             cJSON_Delete);
        if (!root || !cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(root.get(), "ok"))) {
            error = root ? JsonString(root.get(), "error") : "Respons status STB tidak valid";
            if (error.empty()) {
                error = "Respons status STB tidak valid";
            }
            return {};
        }
        const std::string title = JsonString(root.get(), "title");
        const std::string status = JsonString(root.get(), "status");
        const cJSON* paused = cJSON_GetObjectItemCaseSensitive(root.get(), "paused");
        if (!title.empty() && title != "Ora ana lagu") {
            return std::string(cJSON_IsTrue(paused) ? "Dijeda di STB: " : "Diputar di STB: ") +
                   title;
        }
        return status.empty() ? "STB: tidak ada lagu" : "STB: " + status;
    }

    void EnsureVolumeSettingsLoaded() {
        std::call_once(volume_settings_once_, [this]() { LoadVolumeSettings(); });
    }

    static void SaveVolumeSetting(const char* key, int volume) {
        nvs_handle_t handle;
        if (nvs_open("babu-audio", NVS_READWRITE, &handle) != ESP_OK)
            return;
        nvs_set_u8(handle, key, static_cast<uint8_t>(std::clamp(volume, 0, 100)));
        nvs_commit(handle);
        nvs_close(handle);
    }

    static int RelayOutputLevel(const RelayConfig& relay) {
        return relay.on ? (relay.active_low ? 0 : 1) : (relay.active_low ? 1 : 0);
    }

    static bool ConfigureOutput(const RelayConfig& relay) {
        if (relay.pin == GPIO_NUM_NC)
            return true;
        // Preload the inactive level before switching the pin to output mode so
        // active-low relay modules do not see a short ON pulse at initialization.
        gpio_set_level(relay.pin, relay.active_low ? 1 : 0);
        gpio_config_t config = {};
        config.pin_bit_mask = 1ULL << static_cast<unsigned>(relay.pin);
        config.mode = GPIO_MODE_OUTPUT;
        config.pull_up_en = GPIO_PULLUP_DISABLE;
        config.pull_down_en = GPIO_PULLDOWN_DISABLE;
        config.intr_type = GPIO_INTR_DISABLE;
        if (gpio_config(&config) != ESP_OK)
            return false;
        return gpio_set_level(relay.pin, RelayOutputLevel(relay)) == ESP_OK;
    }

    void InitializeRelays() {
        nvs_handle_t handle;
        if (nvs_open("babu-relay", NVS_READWRITE, &handle) == ESP_OK) {
            for (size_t i = 0; i < relays_.size(); ++i) {
                char pin_key[5], low_key[5];
                snprintf(pin_key, sizeof(pin_key), "p%u", static_cast<unsigned>(i));
                snprintf(low_key, sizeof(low_key), "l%u", static_cast<unsigned>(i));
                uint8_t stored_pin = 0, stored_low = relays_[i].active_low;
                char name_key[5];
                snprintf(name_key, sizeof(name_key), "n%u", static_cast<unsigned>(i));
                if (nvs_get_u8(handle, pin_key, &stored_pin) == ESP_OK) {
                    relays_[i].pin =
                        stored_pin == 0 ? GPIO_NUM_NC : static_cast<gpio_num_t>(stored_pin);
                }
                nvs_get_u8(handle, low_key, &stored_low);
                relays_[i].active_low = stored_low != 0;
                size_t name_size = 0;
                if (nvs_get_str(handle, name_key, nullptr, &name_size) == ESP_OK && name_size > 1 &&
                    name_size <= 25) {
                    std::array<char, 25> stored_name{};
                    if (nvs_get_str(handle, name_key, stored_name.data(), &name_size) == ESP_OK) {
                        relay_names_[i] = stored_name.data();
                    }
                }
            }
            nvs_close(handle);
        }

        std::lock_guard<std::mutex> lock(relay_mutex_);
        for (size_t i = 0; i < relays_.size(); ++i) {
            auto& relay = relays_[i];
            if (relay.pin != GPIO_NUM_NC) {
                const int pin = static_cast<int>(relay.pin);
                bool duplicate = false;
                for (size_t previous = 0; previous < i; ++previous) {
                    duplicate |= relays_[previous].pin == relay.pin;
                }
                if (!IsAllowedRelayPin(pin) || duplicate) {
                    ESP_LOGW(TAG, "Relay %u pin %d ditolak; output dinonaktifkan",
                             static_cast<unsigned>(i + 1), pin);
                    relay.pin = GPIO_NUM_NC;
                }
            }
            relay.on = false;
            if (!ConfigureOutput(relay)) {
                ESP_LOGE(TAG, "Gagal menyiapkan relay %u di GPIO %d", static_cast<unsigned>(i + 1),
                         static_cast<int>(relay.pin));
                relay.pin = GPIO_NUM_NC;
            }
        }
    }

    bool SetRelay(size_t index, bool on) {
        if (index >= relays_.size())
            return false;
        std::lock_guard<std::mutex> lock(relay_mutex_);
        auto& relay = relays_[index];
        if (relay.pin == GPIO_NUM_NC)
            return false;
        relay.on = on;
        return gpio_set_level(relay.pin, RelayOutputLevel(relay)) == ESP_OK;
    }

    static std::string NormalizeRelayName(const std::string& name) {
        const auto first = std::find_if_not(name.begin(), name.end(), [](unsigned char character) {
            return std::isspace(character);
        });
        const auto last = std::find_if_not(name.rbegin(), name.rend(), [](unsigned char character) {
                              return std::isspace(character);
                          }).base();
        if (first >= last)
            return {};
        std::string normalized;
        normalized.reserve(static_cast<size_t>(last - first));
        for (auto it = first; it != last; ++it) {
            const unsigned char character = static_cast<unsigned char>(*it);
            normalized.push_back(static_cast<char>(std::tolower(character)));
        }
        return normalized;
    }

    bool SetRelayByName(const std::string& name, bool on) {
        const std::string target = NormalizeRelayName(name);
        std::lock_guard<std::mutex> lock(relay_mutex_);
        for (size_t i = 0; i < relays_.size(); ++i) {
            if (relays_[i].pin != GPIO_NUM_NC && NormalizeRelayName(relay_names_[i]) == target) {
                relays_[i].on = on;
                return gpio_set_level(relays_[i].pin, RelayOutputLevel(relays_[i])) == ESP_OK;
            }
        }
        return false;
    }

    std::string GetRelayListForAi() {
        std::lock_guard<std::mutex> lock(relay_mutex_);
        std::string result;
        for (size_t i = 0; i < relays_.size(); ++i) {
            if (relays_[i].pin == GPIO_NUM_NC)
                continue;
            if (!result.empty())
                result += "; ";
            const std::string name =
                relay_names_[i].empty() ? "Relay " + std::to_string(i + 1) : relay_names_[i];
            result += name + " (GPIO " + std::to_string(static_cast<int>(relays_[i].pin)) + ", " +
                      (relays_[i].on ? "menyala" : "mati") + ")";
        }
        return result.empty() ? "Belum ada relay yang didaftarkan." : result;
    }

    bool ConfigureRelay(size_t index, int pin, bool active_low) {
        if (index >= relays_.size() || (pin != 0 && !IsAllowedRelayPin(pin)))
            return false;
        std::lock_guard<std::mutex> lock(relay_mutex_);
        const gpio_num_t new_pin = pin == 0 ? GPIO_NUM_NC : static_cast<gpio_num_t>(pin);
        for (size_t i = 0; i < relays_.size(); ++i) {
            if (i != index && new_pin != GPIO_NUM_NC && relays_[i].pin == new_pin)
                return false;
        }
        auto& relay = relays_[index];
        if (relay.pin != GPIO_NUM_NC) {
            gpio_set_level(relay.pin, relay.active_low ? 1 : 0);
            gpio_reset_pin(relay.pin);
        }
        relay = {new_pin, active_low, false};
        if (!ConfigureOutput(relay)) {
            relay.pin = GPIO_NUM_NC;
            return false;
        }

        nvs_handle_t handle;
        if (nvs_open("babu-relay", NVS_READWRITE, &handle) != ESP_OK)
            return false;
        char pin_key[5], low_key[5];
        snprintf(pin_key, sizeof(pin_key), "p%u", static_cast<unsigned>(index));
        snprintf(low_key, sizeof(low_key), "l%u", static_cast<unsigned>(index));
        esp_err_t result = nvs_set_u8(handle, pin_key, pin == 0 ? 0 : static_cast<uint8_t>(pin));
        if (result == ESP_OK)
            result = nvs_set_u8(handle, low_key, active_low ? 1 : 0);
        if (result == ESP_OK)
            result = nvs_commit(handle);
        nvs_close(handle);
        return result == ESP_OK;
    }

    int RegisterRelay(int pin, bool active_low, const std::string& name) {
        if (!IsAllowedRelayPin(pin) || name.empty() || name.size() > 24)
            return -1;
        size_t slot = relays_.size();
        {
            std::lock_guard<std::mutex> lock(relay_mutex_);
            for (size_t i = 0; i < relays_.size(); ++i) {
                if (relays_[i].pin == GPIO_NUM_NC) {
                    slot = i;
                    break;
                }
            }
        }
        if (slot == relays_.size() || !ConfigureRelay(slot, pin, active_low))
            return -1;
        nvs_handle_t handle;
        if (nvs_open("babu-relay", NVS_READWRITE, &handle) != ESP_OK) {
            ConfigureRelay(slot, 0, active_low);
            return -1;
        }
        char name_key[5];
        snprintf(name_key, sizeof(name_key), "n%u", static_cast<unsigned>(slot));
        esp_err_t result = nvs_set_str(handle, name_key, name.c_str());
        if (result == ESP_OK)
            result = nvs_commit(handle);
        nvs_close(handle);
        if (result != ESP_OK) {
            ConfigureRelay(slot, 0, active_low);
            return -1;
        }
        {
            std::lock_guard<std::mutex> lock(relay_mutex_);
            relay_names_[slot] = name;
        }
        return static_cast<int>(slot + 1);
    }

    bool RemoveRelay(size_t index) {
        if (index >= relays_.size())
            return false;
        bool active_low;
        {
            std::lock_guard<std::mutex> lock(relay_mutex_);
            active_low = relays_[index].active_low;
        }
        if (!ConfigureRelay(index, 0, active_low))
            return false;
        nvs_handle_t handle;
        if (nvs_open("babu-relay", NVS_READWRITE, &handle) != ESP_OK)
            return false;
        char name_key[5];
        snprintf(name_key, sizeof(name_key), "n%u", static_cast<unsigned>(index));
        esp_err_t result = nvs_erase_key(handle, name_key);
        if (result == ESP_ERR_NVS_NOT_FOUND)
            result = ESP_OK;
        if (result == ESP_OK)
            result = nvs_commit(handle);
        nvs_close(handle);
        if (result == ESP_OK) {
            std::lock_guard<std::mutex> lock(relay_mutex_);
            relay_names_[index].clear();
        }
        return result == ESP_OK;
    }

    void AddRelayStatus(cJSON* root) {
        std::lock_guard<std::mutex> lock(relay_mutex_);
        cJSON* relays = cJSON_AddArrayToObject(root, "relays");
        cJSON* pins = cJSON_AddArrayToObject(root, "relay_pins");
        if (relays == nullptr || pins == nullptr)
            return;
        for (int pin : kRelayPins) {
            cJSON_AddItemToArray(pins, cJSON_CreateNumber(pin));
        }
        for (size_t i = 0; i < relays_.size(); ++i) {
            const auto& relay = relays_[i];
            cJSON* item = cJSON_CreateObject();
            if (item == nullptr)
                continue;
            cJSON_AddNumberToObject(item, "channel", static_cast<double>(i + 1));
            cJSON_AddNumberToObject(item, "pin", relay.pin == GPIO_NUM_NC ? 0 : relay.pin);
            cJSON_AddBoolToObject(item, "active_low", relay.active_low);
            cJSON_AddBoolToObject(item, "on", relay.on);
            cJSON_AddBoolToObject(item, "available", relay.pin != GPIO_NUM_NC);
            cJSON_AddStringToObject(item, "name", relay_names_[i].c_str());
            cJSON_AddItemToArray(relays, item);
        }
    }

    static esp_err_t ControlStatusHandler(httpd_req_t* req) {
        auto* self = static_cast<BabuAiBoard*>(req->user_ctx);
        auto* root = cJSON_CreateObject();
        if (root == nullptr)
            return ESP_ERR_NO_MEM;
        const auto target_settings = self->GetTargetSettings();
        std::string status =
            self->navidrome_player_ ? self->navidrome_player_->GetStatus() : "Pemutar belum siap";
        std::string stb_title;
        int stb_music_volume = -1;
        bool stb_status_fetched = false;
        if (target_settings.first == "stb") {
            std::string response;
            std::string error;
            if (self->GetStbJson("/music/status", response, error, kStbStatusTimeoutMs)) {
                std::unique_ptr<cJSON, decltype(&cJSON_Delete)> stb(
                    cJSON_Parse(response.c_str()), cJSON_Delete);
                if (stb &&
                    cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(stb.get(), "ok"))) {
                    stb_status_fetched = true;
                    stb_title = JsonString(stb.get(), "title");
                    const cJSON* volume =
                        cJSON_GetObjectItemCaseSensitive(stb.get(), "music_volume");
                    if (cJSON_IsNumber(volume)) {
                        stb_music_volume =
                            std::clamp(static_cast<int>(volume->valuedouble), 0, 100);
                    }
                    const std::string stb_status = JsonString(stb.get(), "status");
                    if (!stb_title.empty() && stb_title != "Ora ana lagu") {
                        status = "Diputar dari STB: " + stb_title;
                    } else if (!stb_status.empty()) {
                        status = "STB: " + stb_status;
                    } else {
                        status = "STB: tidak ada lagu";
                    }
                }
            }
            if (!stb_status_fetched) {
                status = "STB tidak dapat dihubungi";
            }
        }
        cJSON_AddStringToObject(root, "status", status.c_str());
        cJSON_AddNumberToObject(root, "volume", self->GetOutputVolume());
        cJSON_AddNumberToObject(root, "ai_volume", self->GetOutputVolume());
        cJSON_AddNumberToObject(
            root, "music_volume",
            stb_music_volume >= 0 ? stb_music_volume : self->GetMusicVolume());
        cJSON_AddNumberToObject(root, "music_routing_version", 1);
        cJSON_AddStringToObject(root, "title",
                                stb_title.empty()
                                    ? (status.starts_with("Memutar: ") ? status.c_str() + 9 : "")
                                    : stb_title.c_str());
        cJSON_AddStringToObject(root, "music_target", target_settings.first.c_str());
        cJSON_AddStringToObject(root, "stb_url", target_settings.second.c_str());
        if (self->navidrome_player_ != nullptr) {
            cJSON_AddStringToObject(root, "navi_url", self->navidrome_player_->GetBaseUrl().c_str());
            cJSON_AddStringToObject(root, "navi_user", self->navidrome_player_->GetUsername().c_str());
            cJSON_AddBoolToObject(root, "navi_configured", self->navidrome_player_->IsConfigured());
        } else {
            cJSON_AddStringToObject(root, "navi_url", "");
            cJSON_AddStringToObject(root, "navi_user", "");
            cJSON_AddBoolToObject(root, "navi_configured", false);
        }
        self->AddRelayStatus(root);
        char* json = cJSON_PrintUnformatted(root);
        cJSON_Delete(root);
        if (json == nullptr)
            return ESP_ERR_NO_MEM;
        httpd_resp_set_type(req, "application/json");
        httpd_resp_set_hdr(req, "Cache-Control", "no-store");
        esp_err_t result = httpd_resp_send(req, json, HTTPD_RESP_USE_STRLEN);
        cJSON_free(json);
        return result;
    }

    static esp_err_t ControlSearchHandler(httpd_req_t* req) {
        auto* self = static_cast<BabuAiBoard*>(req->user_ctx);
        std::array<char, 512> query_string{};
        std::array<char, 121> search_term{};
        if (httpd_req_get_url_query_len(req) >= query_string.size() ||
            httpd_req_get_url_query_str(req, query_string.data(), query_string.size()) != ESP_OK ||
            httpd_query_key_value(query_string.data(), "q", search_term.data(),
                                  search_term.size()) != ESP_OK) {
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Missing or long query");
            return ESP_OK;
        }
        if (self->IsStbTarget()) {
            std::string response;
            std::string error;
            const std::string path =
                "/navidrome/search?q=" + UrlEncode(search_term.data());
            if (!self->GetStbJson(path, response, error)) {
                ESP_LOGW(TAG, "Pencarian Navidrome STB gagal: %s", error.c_str());
                httpd_resp_set_status(req, "502 Bad Gateway");
                httpd_resp_sendstr(req, error.c_str());
                return ESP_OK;
            }
            httpd_resp_set_type(req, "application/json; charset=utf-8");
            httpd_resp_set_hdr(req, "Cache-Control", "no-store");
            return httpd_resp_send(req, response.c_str(), response.size());
        }
        if (!self->navidrome_player_ || !self->navidrome_player_->IsConfigured()) {
            httpd_resp_set_status(req, "503 Service Unavailable");
            httpd_resp_sendstr(req, "Navidrome is not configured");
            return ESP_OK;
        }
        const std::string results = self->navidrome_player_->SearchSongsJson(search_term.data());
        httpd_resp_set_type(req, "application/json; charset=utf-8");
        httpd_resp_set_hdr(req, "Cache-Control", "no-store");
        return httpd_resp_send(req, results.c_str(), results.size());
    }

    static bool HasSameOrigin(httpd_req_t* req) {
        std::array<char, 96> host{};
        std::array<char, 160> origin{};
        if (httpd_req_get_hdr_value_str(req, "Host", host.data(), host.size()) != ESP_OK ||
            httpd_req_get_hdr_value_str(req, "Origin", origin.data(), origin.size()) != ESP_OK) {
            return false;
        }
        const char* authority = std::strstr(origin.data(), "://");
        return authority != nullptr && std::strcmp(authority + 3, host.data()) == 0;
    }

    static esp_err_t ControlActionHandler(httpd_req_t* req) {
        auto* self = static_cast<BabuAiBoard*>(req->user_ctx);
        if (!HasSameOrigin(req)) {
            httpd_resp_send_err(req, HTTPD_403_FORBIDDEN, "Same-origin request required");
            return ESP_OK;
        }
        if (req->content_len == 0 || req->content_len > 4096) {
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid request size");
            return ESP_OK;
        }
        std::unique_ptr<char[]> body(new (std::nothrow) char[req->content_len + 1]);
        if (!body) {
            httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Out of memory");
            return ESP_OK;
        }
        size_t received = 0;
        while (received < req->content_len) {
            int count = httpd_req_recv(req, body.get() + received, req->content_len - received);
            if (count <= 0)
                return ESP_FAIL;
            received += static_cast<size_t>(count);
        }
        body[received] = '\0';
        cJSON* root = cJSON_ParseWithLength(body.get(), received);
        if (root == nullptr) {
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid JSON");
            return ESP_OK;
        }
        const cJSON* action = cJSON_GetObjectItemCaseSensitive(root, "action");
        bool ok = action != nullptr && cJSON_IsString(action);
        bool deferred = false;
        bool stb_action = false;
        std::string message = "Perintah tidak dikenal";
        if (ok) {
            const std::string command = action->valuestring;
            if (command == "relay") {
                const cJSON* channel = cJSON_GetObjectItemCaseSensitive(root, "channel");
                const cJSON* on = cJSON_GetObjectItemCaseSensitive(root, "on");
                ok = cJSON_IsNumber(channel) && cJSON_IsBool(on) &&
                     self->SetRelay(static_cast<size_t>(channel->valueint - 1), cJSON_IsTrue(on));
                if (ok)
                    message = std::string("Relay ") + std::to_string(channel->valueint) +
                              (cJSON_IsTrue(on) ? " dinyalakan" : " dimatikan");
            } else if (command == "relay_config") {
                const cJSON* channel = cJSON_GetObjectItemCaseSensitive(root, "channel");
                const cJSON* pin = cJSON_GetObjectItemCaseSensitive(root, "pin");
                const cJSON* active_low = cJSON_GetObjectItemCaseSensitive(root, "active_low");
                ok = cJSON_IsNumber(channel) && cJSON_IsNumber(pin) && cJSON_IsBool(active_low) &&
                     self->ConfigureRelay(static_cast<size_t>(channel->valueint - 1), pin->valueint,
                                          cJSON_IsTrue(active_low));
                if (ok)
                    message = "Pengaturan relay disimpan";
            } else if (command == "relay_register") {
                const cJSON* pin = cJSON_GetObjectItemCaseSensitive(root, "pin");
                const cJSON* active_low = cJSON_GetObjectItemCaseSensitive(root, "active_low");
                const cJSON* name = cJSON_GetObjectItemCaseSensitive(root, "name");
                const int channel =
                    cJSON_IsNumber(pin) && cJSON_IsBool(active_low) && cJSON_IsString(name) &&
                            std::strlen(name->valuestring) <= 24
                        ? self->RegisterRelay(pin->valueint, cJSON_IsTrue(active_low),
                                              name->valuestring)
                        : -1;
                ok = channel > 0;
                message = ok ? std::string("Relay ") + std::to_string(channel) + " didaftarkan"
                             : "GPIO tidak tersedia, sudah dipakai, atau kapasitas relay penuh";
            } else if (command == "relay_remove") {
                const cJSON* channel = cJSON_GetObjectItemCaseSensitive(root, "channel");
                ok = cJSON_IsNumber(channel) &&
                     self->RemoveRelay(static_cast<size_t>(channel->valueint - 1));
                if (ok)
                    message = "Pendaftaran relay dihapus";
            } else if (self->IsStbTarget() &&
                       (command == "toggle" || command == "next" || command == "previous" ||
                        command == "random" || command == "stop" || command == "play_id" ||
                        command == "play_search" || command == "music_volume" ||
                        command == "volume" || command == "seek")) {
                stb_action = true;
                if (command == "music_volume" || command == "volume") {
                    const cJSON* volume = cJSON_GetObjectItemCaseSensitive(root, "volume");
                    ok = cJSON_IsNumber(volume) && std::isfinite(volume->valuedouble);
                    if (ok) {
                        ok = self->PostStbMusicAction(root, message);
                        if (ok) {
                            self->SetMusicVolume(static_cast<int>(
                                std::clamp(volume->valuedouble, 0.0, 100.0)));
                        }
                    }
                } else {
                    ok = self->PostStbMusicAction(root, message);
                }
            } else if (!self->navidrome_player_) {
                ok = false;
            } else if (command == "toggle") {
                Application::GetInstance().Schedule([self]() {
                    if (self->navidrome_player_ != nullptr)
                        self->navidrome_player_->TogglePause();
                });
                ok = true;
                deferred = true;
            } else if (command == "next")
                ok = self->navidrome_player_->PlayNext();
            else if (command == "random")
                ok = self->navidrome_player_->PlayRandom();
            else if (command == "stop") {
                self->navidrome_player_->Stop();
                ok = true;
            } else if (command == "play_id") {
                const cJSON* id = cJSON_GetObjectItemCaseSensitive(root, "id");
                const cJSON* title = cJSON_GetObjectItemCaseSensitive(root, "title");
                ok = cJSON_IsString(id) && cJSON_IsString(title) &&
                     self->navidrome_player_->PlaySongById(id->valuestring, title->valuestring);
            } else if (command == "ai_volume") {
                const cJSON* volume = cJSON_GetObjectItemCaseSensitive(root, "volume");
                ok = cJSON_IsNumber(volume);
                if (ok)
                    self->SetOutputVolume(std::clamp(volume->valueint, 0, 100));
            } else if (command == "music_volume" || command == "volume") {
                const cJSON* volume = cJSON_GetObjectItemCaseSensitive(root, "volume");
                ok = cJSON_IsNumber(volume);
                if (ok)
                    self->SetMusicVolume(std::clamp(volume->valueint, 0, 100));
            } else if (command == "chat") {
                const cJSON* text = cJSON_GetObjectItemCaseSensitive(root, "text");
                ok = cJSON_IsString(text) && std::strlen(text->valuestring) <= 180;
                if (ok) {
                    ok = Application::GetInstance().SendTextCommand(text->valuestring);
                }
            } else if (command == "set_target") {
                const cJSON* target = cJSON_GetObjectItemCaseSensitive(root, "target");
                const cJSON* stb_url = cJSON_GetObjectItemCaseSensitive(root, "stb_url");
                if (target != nullptr && cJSON_IsString(target)) {
                    std::string t = target->valuestring;
                    std::string u = (stb_url != nullptr && cJSON_IsString(stb_url))
                                        ? stb_url->valuestring
                                        : self->GetTargetSettings().second;
                    ok = self->SaveTargetSettings(t, u);
                    message = ok ? "Target pemutaran diubah ke " + t
                                 : "Target musik atau URL proxy STB tidak valid";
                }
            } else if (command == "set_navidrome") {
                const cJSON* url = cJSON_GetObjectItemCaseSensitive(root, "url");
                const cJSON* user = cJSON_GetObjectItemCaseSensitive(root, "user");
                const cJSON* pass = cJSON_GetObjectItemCaseSensitive(root, "pass");
                if (url != nullptr && cJSON_IsString(url) && user != nullptr &&
                    cJSON_IsString(user)) {
                    std::string p =
                        (pass != nullptr && cJSON_IsString(pass)) ? pass->valuestring : "";
                    self->SaveNavidromeSettings(url->valuestring, user->valuestring, p);
                    ok = true;
                    message = "Pengaturan akun Navidrome disimpan";
                }
            } else {
                ok = false;
            }
            if (ok &&
                (command == "volume" || command == "music_volume" || command == "ai_volume")) {
                const cJSON* volume = cJSON_GetObjectItemCaseSensitive(root, "volume");
                message = std::string(command == "ai_volume" ? "Volume AI diatur ke "
                                                             : "Volume musik diatur ke ") +
                          std::to_string(std::clamp(volume->valueint, 0, 100)) + "%";
            } else if (ok && deferred) {
                message = "Perintah jeda/lanjut diterima";
            } else if (ok && !stb_action && command != "relay" && command != "relay_config" &&
                       command != "relay_register" && command != "relay_remove" &&
                       command != "set_target" && command != "set_navidrome") {
                message = command == "chat" ? "Perintah AI dijadwalkan"
                                            : (self->navidrome_player_ != nullptr
                                                   ? self->navidrome_player_->GetStatus()
                                                   : "Perintah diterima");
            }
        } else {
            ok = false;
        }
        cJSON_Delete(root);
        cJSON* response = cJSON_CreateObject();
        cJSON_AddBoolToObject(response, "ok", ok);
        cJSON_AddStringToObject(response, "message", message.c_str());
        char* json = cJSON_PrintUnformatted(response);
        cJSON_Delete(response);
        if (json == nullptr)
            return ESP_ERR_NO_MEM;
        httpd_resp_set_type(req, "application/json");
        esp_err_t result = httpd_resp_send(req, json, HTTPD_RESP_USE_STRLEN);
        cJSON_free(json);
        return result;
    }

    void InitializeControlApi() {
        if (control_server_ != nullptr)
            return;

        httpd_config_t config = HTTPD_DEFAULT_CONFIG();
        config.server_port = 80;
        config.max_open_sockets = 4;
        config.stack_size = 8192;
        config.lru_purge_enable = true;
        if (httpd_start(&control_server_, &config) != ESP_OK) {
            ESP_LOGE(TAG, "Failed to start device control API");
            return;
        }
        const httpd_uri_t routes[] = {
            {.uri = "/api/status",
             .method = HTTP_GET,
             .handler = ControlStatusHandler,
             .user_ctx = this},
            {.uri = "/api/search",
             .method = HTTP_GET,
             .handler = ControlSearchHandler,
             .user_ctx = this},
            {.uri = "/api/action",
             .method = HTTP_POST,
             .handler = ControlActionHandler,
             .user_ctx = this},
        };
        for (const auto& route : routes)
            httpd_register_uri_handler(control_server_, &route);
        ESP_LOGI(TAG, "Device control API listening on port 80");
    }

    void InitializeDisplay() {
        // Buat bus I2C untuk OLED dengan GPIO SDA dan SCL dari config.h.
        i2c_master_bus_config_t bus_config = {
            .i2c_port = I2C_NUM_0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags =
                {
                    .enable_internal_pullup = 1,
                },
        };
        esp_err_t err = i2c_new_master_bus(&bus_config, &display_i2c_bus_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "I2C bus init gagal (SDA=%d SCL=%d): %s", DISPLAY_SDA_PIN,
                     DISPLAY_SCL_PIN, esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        // Scan I2C untuk mencari perangkat yang terhubung.
        bool device_found = false;
        for (uint8_t addr = 0x01; addr < 0x7F; ++addr) {
            if (i2c_master_probe(display_i2c_bus_, addr, 50) == ESP_OK) {
                ESP_LOGI(TAG, "I2C device ditemukan di alamat 0x%02X", addr);
                device_found = true;
            }
        }
        if (!device_found) {
            ESP_LOGW(TAG, "Tidak ada perangkat I2C ditemukan — periksa kabel SDA/SCL");
        }

        // Atur komunikasi panel OLED di atas bus I2C, termasuk alamat perangkat.
        esp_lcd_panel_io_i2c_config_t io_config = {
            .dev_addr = DISPLAY_I2C_ADDRESS,
            .scl_speed_hz = 400 * 1000,
            .control_phase_bytes = 1,
            .dc_bit_offset = 6,
            .lcd_cmd_bits = 8,
            .lcd_param_bits = 8,
            .on_color_trans_done = nullptr,
            .user_ctx = nullptr,
            .flags =
                {
                    .dc_low_on_data = 0,
                    .disable_control_phase = 0,
                },
        };
        err = esp_lcd_new_panel_io_i2c(display_i2c_bus_, &io_config, &display_panel_io_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "OLED panel IO init gagal (addr=0x%02X): %s", DISPLAY_I2C_ADDRESS,
                     esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = GPIO_NUM_NC;
        panel_config.bits_per_pixel = 1;

        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = static_cast<uint8_t>(DISPLAY_HEIGHT),
        };
        panel_config.vendor_config = &ssd1306_config;
        err = esp_lcd_new_panel_ssd1306(display_panel_io_, &panel_config, &display_panel_);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "SSD1306 panel init gagal: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        // Reset dan mulai panel; jika gagal, lanjutkan tanpa layar.
        err = esp_lcd_panel_reset(display_panel_);
        if (err == ESP_OK) {
            err = esp_lcd_panel_init(display_panel_);
        }
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Inisialisasi OLED gagal: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }

        err = esp_lcd_panel_disp_on_off(display_panel_, true);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "OLED disp_on_off gagal: %s", esp_err_to_name(err));
            display_ = new NoDisplay();
            return;
        }
        display_ = new OledDisplay(display_panel_io_, display_panel_, DISPLAY_WIDTH, DISPLAY_HEIGHT,
                                   DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);
    }

    void InitializeButtons() {
        // Tekan BOOT saat perangkat baru menyala untuk masuk ke pengaturan Wi-Fi.
        // Saat perangkat sudah berjalan, tombol mengaktifkan atau menghentikan percakapan.
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            app.ToggleChatState();
        });
    }

    static void StbStatusTaskEntry(void* context) {
        static_cast<BabuAiBoard*>(context)->StbStatusTask();
    }

    void StartStbStatusTask() {
        if (stb_status_task_ != nullptr) {
            return;
        }
        if (xTaskCreate(StbStatusTaskEntry, "stb_status", 4096, this, 2,
                        &stb_status_task_) != pdPASS) {
            stb_status_task_ = nullptr;
            ESP_LOGE(TAG, "Gagal membuat task status musik STB");
        }
    }

    void StbStatusTask() {
        std::string last_display;
        std::string last_error;
        bool was_online = false;
        while (true) {
            if (!IsStbTarget()) {
                if (!last_display.empty()) {
                    const std::string previous = last_display;
                    Application::GetInstance().Schedule([previous]() {
                        auto* display = Board::GetInstance().GetDisplay();
                        if (display != nullptr) {
                            display->RemoveChatMessage("system", previous.c_str());
                        }
                    });
                    last_display.clear();
                }
                last_error.clear();
                was_online = false;
                vTaskDelay(pdMS_TO_TICKS(7000));
                continue;
            }

            std::string error;
            const std::string status = GetStbMusicStatus(error, kStbStatusTimeoutMs);
            if (!status.empty()) {
                last_error.clear();
                was_online = true;
                if (status != last_display) {
                    last_display = status;
                    Application::GetInstance().Schedule([status]() {
                        auto* display = Board::GetInstance().GetDisplay();
                        if (display != nullptr) {
                            display->SetChatMessage("system", status.c_str());
                        }
                    });
                }
            } else {
                if (error != last_error) {
                    ESP_LOGW(TAG, "Status musik STB tidak tersedia: %s", error.c_str());
                    last_error = error;
                }
                if (was_online || last_display.empty()) {
                    const std::string unavailable = "STB: koneksi terputus";
                    last_display = unavailable;
                    Application::GetInstance().Schedule([unavailable]() {
                        auto* display = Board::GetInstance().GetDisplay();
                        if (display != nullptr) {
                            display->SetChatMessage("system", unavailable.c_str());
                        }
                    });
                }
                was_online = false;
            }
            vTaskDelay(pdMS_TO_TICKS(7000));
        }
    }

    bool RunButtonMusicAction(const char* action) {
        if (IsStbTarget()) {
            std::string message;
            if (!SendStbMusicAction(action, nullptr, nullptr, message)) {
                ESP_LOGW(TAG, "Aksi tombol musik ke STB gagal: %s", message.c_str());
                Application::GetInstance().Schedule([message]() {
                    auto* display = Board::GetInstance().GetDisplay();
                    if (display != nullptr) {
                        display->SetChatMessage("system", message.c_str());
                    }
                });
                return false;
            }
            return true;
        }
        if (!navidrome_player_) {
            return false;
        }
        if (std::strcmp(action, "random") == 0) {
            return navidrome_player_->PlayRandom();
        }
        if (std::strcmp(action, "next") == 0) {
            return navidrome_player_->PlayNext();
        }
        if (std::strcmp(action, "toggle") == 0) {
            return navidrome_player_->TogglePause();
        }
        return false;
    }

    void InitializeMediaButtons() {
#if CONFIG_BABU_AI_PROFILE_ENHANCED
        play_pause_button_.OnClick([this]() {
            RunButtonMusicAction("toggle");
        });
        play_pause_button_.OnDoubleClick([this]() {
            RunButtonMusicAction("previous");
        });
        play_pause_button_.OnMultipleClick([this]() {
            RunButtonMusicAction("stop");
        }, 3);
        play_pause_button_.OnLongPress([this]() {
            Application::GetInstance().ToggleChatState();
        });

        random_next_button_.OnClick([this]() {
            RunButtonMusicAction("next");
        });
        random_next_button_.OnDoubleClick([this]() {
            RunButtonMusicAction("random");
        });
        random_next_button_.OnMultipleClick([this]() {
            std::string message;
            const int volume = std::clamp(GetMusicVolume() + 10, 0, 100);
            SetTargetMusicVolume(volume, message);
        }, 3);
        random_next_button_.OnLongPress([this]() {
            std::string message;
            const int volume = std::clamp(GetMusicVolume() - 10, 0, 100);
            SetTargetMusicVolume(volume, message);
        });
#endif
    }

    void InitializeTools() {
        InitializeRelays();
        navidrome_player_ = std::make_unique<NavidromePlayer>(
            Application::GetInstance().GetAudioService(), CONFIG_BABU_AI_NAVIDROME_URL,
            CONFIG_BABU_AI_NAVIDROME_USERNAME, CONFIG_BABU_AI_NAVIDROME_PASSWORD);
        LoadNavidromeSettings();
        InitializeMediaButtons();
        auto& mcp_server = McpServer::GetInstance();

        mcp_server.AddTool(
            "self.relay.list",
            "List every relay currently registered on the DEMET AI web page, including its exact "
            "user-defined name, GPIO, and current state. Always call this before controlling a "
            "relay by the user's chosen name.",
            PropertyList(),
            [this](const PropertyList&) -> ToolResult { return GetRelayListForAi(); });

        mcp_server.AddTool(
            "self.relay.set",
            "Turn a configured relay on or off by its exact user-defined name. Use "
            "self.relay.list first to find the names registered in the DEMET AI phone web page. "
            "Do not substitute a generic word such as relay when the user has named the device.",
            PropertyList({Property("name", kPropertyTypeString).SetMaxLength(24),
                          Property("on", kPropertyTypeBoolean)}),
            [this](const PropertyList& properties) -> ToolResult {
                const auto& name = properties["name"].value<std::string>();
                const bool on = properties["on"].value<bool>();
                if (!SetRelayByName(name, on)) {
                    return std::unexpected(
                        "Nama relay tidak ditemukan atau gagal diubah. "
                        "Periksa daftar dengan self.relay.list.");
                }
                return name + (on ? " dinyalakan." : " dimatikan.");
            });

        mcp_server.AddTool(
            "self.music.play_random",
            "Play random music from the DEMET AI Navidrome library using the selected output "
            "(ESP32 or STB). Use when the user asks to play music or says 'putar musik'.",
            PropertyList(), [this](const PropertyList&) -> ToolResult {
                if (IsStbTarget()) {
                    std::string message;
                    if (!SendStbMusicAction("random", nullptr, nullptr, message)) {
                        return std::unexpected(message);
                    }
                    return std::string("Musik acak diputar melalui STB.");
                }
                if (!navidrome_player_->IsConfigured()) {
                    return std::unexpected(
                        "Navidrome belum dikonfigurasi. Atur akun Navidrome melalui web kontrol DEMET AI.");
                }
                if (!navidrome_player_->PlayRandom(true)) {
                    return std::unexpected("Gagal memulai pemutaran musik Navidrome.");
                }
                return std::string(
                    "Permintaan musik diterima. Sampaikan konfirmasi singkat kepada pengguna; "
                    "musik mulai setelah ucapan selesai.");
            });

        mcp_server.AddTool(
            "self.music.next",
            "Play the next song on the currently selected music output. Use when the user says "
            "'lagu berikutnya'.",
            PropertyList(), [this](const PropertyList&) -> ToolResult {
                if (IsStbTarget()) {
                    std::string message;
                    if (!SendStbMusicAction("next", nullptr, nullptr, message)) {
                        return std::unexpected(message);
                    }
                    return std::string("Lagu berikutnya diputar melalui STB.");
                }
                if (!navidrome_player_->IsConfigured()) {
                    return std::unexpected(
                        "Navidrome belum dikonfigurasi. Atur akun Navidrome melalui web kontrol DEMET AI.");
                }
                if (!navidrome_player_->PlayNext(true)) {
                    return std::unexpected("Failed to request the next Navidrome track.");
                }
                return std::string(
                    "Permintaan lagu berikutnya diterima. Musik mulai setelah ucapan selesai.");
            });

        mcp_server.AddTool(
            "self.music.search",
            "Search the DEMET AI Navidrome music library for songs matching the user's title or "
            "artist. Return several choices and offer them to the user without starting playback.",
            PropertyList({Property("query", kPropertyTypeString).SetMaxLength(120)}),
            [this](const PropertyList& properties) -> ToolResult {
                if (IsStbTarget()) {
                    const auto& query = properties["query"].value<std::string>();
                    std::string error;
                    const std::string choices =
                        FormatStbSongs("/navidrome/search?q=" + UrlEncode(query), error);
                    if (choices.empty()) {
                        return std::unexpected(error);
                    }
                    return choices;
                }
                if (!navidrome_player_->IsConfigured()) {
                    return std::unexpected("Navidrome belum dikonfigurasi.");
                }
                const auto result =
                    navidrome_player_->SearchSongs(properties["query"].value<std::string>());
                return result;
            });

        mcp_server.AddTool(
            "self.music.recommend",
            "Suggest up to five random songs from the DEMET AI Navidrome library. Do not start "
            "playback; tell the user the choices and ask which one they want.",
            PropertyList(), [this](const PropertyList&) -> ToolResult {
                if (IsStbTarget()) {
                    std::string error;
                    const std::string choices = FormatStbSongs("/navidrome/random?size=5", error);
                    if (choices.empty()) {
                        return std::unexpected(error);
                    }
                    return choices;
                }
                if (!navidrome_player_->IsConfigured()) {
                    return std::unexpected("Navidrome belum dikonfigurasi.");
                }
                return navidrome_player_->RecommendSongs();
            });

        mcp_server.AddTool(
            "self.music.play_song",
            "Find a song by title, artist, or both in the DEMET AI Navidrome library and play the "
            "best matching result. Use this only when the user explicitly asks to play a song.",
            PropertyList({Property("query", kPropertyTypeString).SetMaxLength(120)}),
            [this](const PropertyList& properties) -> ToolResult {
                if (IsStbTarget()) {
                    std::string message;
                    if (!SendStbMusicAction("play_search", "query",
                                            properties["query"].value<std::string>().c_str(),
                                            message)) {
                        return std::unexpected(message);
                    }
                    return std::string("Lagu diminta diputar melalui STB.");
                }
                if (!navidrome_player_->IsConfigured()) {
                    return std::unexpected("Navidrome belum dikonfigurasi.");
                }
                const auto& query = properties["query"].value<std::string>();
                if (!navidrome_player_->PlaySong(query, true)) {
                    return std::unexpected("Lagu tidak ditemukan atau pemutaran gagal dimulai.");
                }
                return std::string(
                    "Lagu ditemukan. Sampaikan judul lagu kepada pengguna; "
                    "pemutaran dimulai setelah ucapan selesai.");
            });

        mcp_server.AddTool(
            "self.music.toggle_pause",
            "Pause or resume Navidrome playback. Resume continues the current track or starts "
            "the next random track if the previous track already ended.",
            PropertyList(), [this](const PropertyList&) -> ToolResult {
                if (IsStbTarget()) {
                    std::string message;
                    if (!SendStbMusicAction("toggle", nullptr, nullptr, message)) {
                        return std::unexpected(message);
                    }
                    std::string error;
                    const std::string status = GetStbMusicStatus(error);
                    return status.empty() ? message : status;
                }
                if (!navidrome_player_->TogglePause()) {
                    return std::unexpected("Failed to pause or resume Navidrome playback.");
                }
                return navidrome_player_->GetStatus();
            });

        mcp_server.AddTool(
            "self.music.set_volume",
            "Set music output volume from 0 to 100 on the currently selected output, ESP32 or STB.",
            PropertyList({Property("volume", kPropertyTypeInteger, 0, 100)}),
            [this](const PropertyList& properties) -> ToolResult {
                std::string message;
                if (!SetTargetMusicVolume(properties["volume"].value<int>(), message)) {
                    return std::unexpected(message);
                }
                return message;
            });

        mcp_server.AddTool("self.music.stop",
                           "Stop Navidrome music playback. Use when the user says "
                           "'hentikan musik'.",
                           PropertyList(), [this](const PropertyList&) -> ToolResult {
                               if (IsStbTarget()) {
                                   std::string message;
                                   if (!SendStbMusicAction("stop", nullptr, nullptr, message)) {
                                       return std::unexpected(message);
                                   }
                                   return std::string("Musik STB dihentikan.");
                               }
                               navidrome_player_->Stop();
                               return std::string("Music playback stopped.");
                           });

        mcp_server.AddTool(
            "self.music.status", "Get the current status of Navidrome music playback.",
            PropertyList(),
            [this](const PropertyList&) -> ToolResult {
                if (IsStbTarget()) {
                    std::string error;
                    const std::string status = GetStbMusicStatus(error);
                    if (status.empty()) {
                        return std::unexpected(error);
                    }
                    return status;
                }
                return navidrome_player_->GetStatus();
            });
    }

public:
    BabuAiBoard()
        : boot_button_(BOOT_BUTTON_GPIO)
#if CONFIG_BABU_AI_PROFILE_ENHANCED
          ,
          play_pause_button_(MEDIA_PLAY_PAUSE_BUTTON_GPIO, false, 1500, 0),
          random_next_button_(MEDIA_RANDOM_NEXT_BUTTON_GPIO, false, 1500, 0)
#endif
    {
        InitializeDisplay();
        InitializeButtons();
        InitializeTools();
    }

    void OnNetworkConnected() override {
        EnsureVolumeSettingsLoaded();
        InitializeControlApi();
        StartStbStatusTask();
    }

    int GetOutputVolume() override {
        EnsureVolumeSettingsLoaded();
        std::lock_guard<std::mutex> lock(volume_mutex_);
        return ai_volume_;
    }

    void SetOutputVolume(int volume) override {
        EnsureVolumeSettingsLoaded();
        const int clamped = std::clamp(volume, 0, 100);
        {
            std::lock_guard<std::mutex> lock(volume_mutex_);
            ai_volume_ = clamped;
        }
        SaveVolumeSetting("ai_vol", clamped);
    }

    int GetMusicVolume() {
        EnsureVolumeSettingsLoaded();
        std::lock_guard<std::mutex> lock(volume_mutex_);
        return music_volume_;
    }

    void SetMusicVolume(int volume) {
        EnsureVolumeSettingsLoaded();
        const int clamped = std::clamp(volume, 0, 100);
        {
            std::lock_guard<std::mutex> lock(volume_mutex_);
            music_volume_ = clamped;
        }
        if (navidrome_player_ != nullptr)
            navidrome_player_->SetMusicVolume(clamped);
        SaveVolumeSetting("music_vol", clamped);
    }

    bool UsesPerTaskOutputVolume() const override { return true; }

    AudioCodec* GetAudioCodec() override {
        // Susunan parameter: format masuk/keluar, pin speaker, lalu pin mikrofon.
        static NoAudioCodecSimplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
                                               AUDIO_I2S_SPK_GPIO_BCLK, AUDIO_I2S_SPK_GPIO_LRCK,
                                               AUDIO_I2S_SPK_GPIO_DOUT, AUDIO_I2S_MIC_GPIO_SCK,
                                               AUDIO_I2S_MIC_GPIO_WS, AUDIO_I2S_MIC_GPIO_DIN);
        return &audio_codec;
    }

    Display* GetDisplay() override { return display_; }

    const char* GetStartupGreeting() override { return "Halo, saya DEMET AI"; }

    void OnAssistantSpeechStarted() override {
        if (navidrome_player_) {
            navidrome_player_->OnAssistantSpeechStarted();
        }
    }

    void OnAssistantSpeechPlaybackDrained() override {
        if (navidrome_player_) {
            navidrome_player_->OnAssistantSpeechPlaybackDrained();
        }
    }

    void OnAssistantActivityChanged(bool active) override {
        if (navidrome_player_) {
            navidrome_player_->SetAssistantActive(active);
        }
    }
};

DECLARE_BOARD(BabuAiBoard);
