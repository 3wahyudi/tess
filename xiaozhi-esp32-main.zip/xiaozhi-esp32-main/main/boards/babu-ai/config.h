#ifndef BABU_AI_BOARD_CONFIG_H
#define BABU_AI_BOARD_CONFIG_H

#include <driver/gpio.h>

// Format audio yang digunakan jalur mikrofon (masuk) dan speaker (keluar).
#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// Jalur mikrofon I2S:
// WS = penanda awal frame audio, SCK = clock bit, DIN = data dari mikrofon ke ESP32.
// Pemetaan GPIO berdasarkan informasi pengguna; cocokkan lagi dengan skematik board.
#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_4
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_5
#define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_6

// Jalur speaker/amplifier I2S:
// DOUT = data audio dari ESP32 ke amplifier, BCLK = clock bit, LRCK = clock kanal audio.
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_7
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_15
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_16

// Tombol BOOT aktif-rendah: GPIO terbaca LOW ketika tombol ditekan.
// Ganti dengan GPIO_NUM_NC jika tombol tidak tersedia atau tidak digunakan.
#define BOOT_BUTTON_GPIO GPIO_NUM_0

// Tombol media aktif-rendah; hubungkan masing-masing tombol antara GPIO dan GND.
#define MEDIA_PLAY_PAUSE_BUTTON_GPIO GPIO_NUM_1
#define MEDIA_RANDOM_NEXT_BUTTON_GPIO GPIO_NUM_2

// OLED I2C monokrom 128x32; GPIO berdasarkan pemetaan yang diberikan pengguna.
// Pengendali SSD1306 dan alamat 0x3C masih asumsi; pastikan dari modul/skematik.
// SDA membawa data I2C dan SCL membawa sinyal clock.
#define DISPLAY_SDA_PIN     GPIO_NUM_11
#define DISPLAY_SCL_PIN     GPIO_NUM_12
#define DISPLAY_I2C_ADDRESS 0x3C
#define DISPLAY_WIDTH       128
#define DISPLAY_HEIGHT      32
// Balik arah tampilan secara horizontal (X) dan vertikal (Y), bila diperlukan.
#define DISPLAY_MIRROR_X    true
#define DISPLAY_MIRROR_Y    true

#endif // BABU_AI_BOARD_CONFIG_H
