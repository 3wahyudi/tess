# Board DEMET AI ESP32-S3

Untuk melihat tahapan proyek, status pekerjaan, dan catatan perubahan DEMET AI,
buka [Panduan Proyek DEMET AI](../../../PANDUAN.md).

Profil board untuk proyek DEMET AI: ESP32-S3 N16R8, mikrofon INMP441, amplifier
MAX98357A, dan OLED monokrom 0,91 inci 128x32. Model/revisi board dan skematik
belum dikonfirmasi. GPIO di `config.h` mengikuti pemetaan yang diberikan
pengguna, tetapi masih perlu dicocokkan dengan skematik board fisik.

## Cara mengubah jalur GPIO

Ubah nilai `GPIO_NUM_...` pada `config.h` di folder ini. Firmware membaca
pengaturan dari file tersebut, sehingga biasanya perubahan jalur tidak perlu
dilakukan di `babu_ai_board.cc`.

| Sinyal | GPIO | Fungsi |
| --- | ---: | --- |
| Mikrofon WS | 4 | Penanda batas frame/kata pada audio I2S |
| Mikrofon SCK | 5 | Clock bit I2S untuk mikrofon |
| Mikrofon DIN | 6 | Jalur data audio dari mikrofon ke ESP32 |
| Speaker DIN amplifier (DOUT ESP32) | 7 | Jalur data audio dari ESP32 ke MAX98357A |
| Speaker BCLK | 15 | Clock bit I2S untuk speaker |
| Speaker LRCK | 16 | Clock pemilih kanal/kata audio speaker |
| OLED SDA | 11 | Jalur data komunikasi I2C ke OLED |
| OLED SCL (disebut SCK pada pemetaan) | 12 | Jalur clock komunikasi I2C ke OLED |
| Tombol BOOT | 0 | Tombol aktif-rendah; gunakan `GPIO_NUM_NC` jika tidak tersedia |
| Tombol musik 1 | 1 | 1x Play/Pause; 2x Previous; 3x Stop; lama: AI |
| Tombol musik 2 | 2 | 1x Next; 2x Random; 3x volume naik; lama: volume turun |

## Kandidat GPIO relay

UI HP menyediakan 14 kandidat GPIO yang belum dipakai firmware: **8, 9, 10,
13, 14, 17, 18, 21, 38, 39, 40, 41, 42, dan 47**. GPIO37 tidak ditawarkan
karena konfigurasi aktif memakai PSRAM octal, yang menggunakan jalur GPIO
33-37. GPIO38 dapat digunakan oleh LED RGB pada beberapa varian papan, jadi
pastikan tidak ada LED/perangkat lain di GPIO38 pada board fisik. Ketersediaan
header DEMET AI dan skematik belum dikonfirmasi. Hindari GPIO0/3/45/46
(strapping), GPIO19/20 (USB), GPIO26-37 (flash/PSRAM pada konfigurasi modul
octal), serta GPIO1/2 yang dipakai tombol media.

Belum ada pin relay yang didaftarkan secara bawaan. Daftarkan nomor GPIO dan
polaritas modul melalui bagian **Kontrol Perangkat** pada web DEMET AI di STB.
Pin yang terdaftar tampil sebagai baris kontrol dengan sakelar geser dan tombol
hapus.
Maksimal enam pin unik dapat didaftarkan; pengaturan disimpan di NVS dan semua
output mulai dalam keadaan mati setelah reboot. Perintah AI memakai nomor kanal
yang tampil di baris UI (misalnya, “nyalakan relay 1”). GPIO37 tidak dapat
dipakai pada konfigurasi PSRAM octal aktif. Koneksi langsung kumparan relay ke
GPIO dilarang; gunakan modul relay/driver transistor yang sesuai dan catu daya
terpisah.

Pada UI web STB, pendaftaran relay meminta nama bebas, pilihan GPIO yang belum
terdaftar, dan polaritas aktif HIGH/LOW. Nama tampil pada baris sakelar dan
disimpan di NVS ESP32 melalui API. Pemutaran trek yang dipilih dari hasil
pencarian berlanjut otomatis ke lagu lain di koleksi Navidrome; tombol lanjut
setelah trek selesai saat dijeda mengulang trek tersebut.

Profil ini mengatur INMP441 sebagai mikrofon I2S dan MAX98357A sebagai amplifier
I2S pada jalur terpisah. Nilai GPIO di atas berasal dari pemetaan pengguna dan
tetap perlu dicocokkan dengan skematik/wiring board.

Tombol GPIO1 dan GPIO2 aktif-rendah: hubungkan tombol sesaat dari GPIO ke GND.
GPIO1 (`Tombol 1`) mengontrol pemutaran: sekali tekan Play/Pause, dua kali
Previous, tiga kali Stop, tekan lama membuka/mengakhiri percakapan AI.
GPIO2 (`Tombol 2`) mengontrol antrean dan volume: sekali tekan Next, dua kali
Random, tiga kali menaikkan volume musik 10%, tekan lama menurunkan volume
musik 10%. Semua aksi diteruskan ke MPV STB ketika target keluaran adalah STB
dan tetap memakai Navidrome ESP32 ketika target masih ESP32.
Tombol RESET/EN dan BOOT bawaan tetap berfungsi seperti sebelumnya; RESET/EN
adalah reset hardware, bukan tombol yang dapat dibaca firmware.

Di SDK Configuration Editor, opsi **DEMET AI media buttons** mengaktifkan tombol
GPIO1/GPIO2. Wake word board ini sekarang memakai WakeNet AFE **"Alexa" saja**;
custom MultiNet phrase dinonaktifkan karena frasa sebelumnya sering tidak
terdeteksi secara konsisten. Musik lokal tetap membiarkan deteksi Alexa aktif.

Selama musik berjalan, AI berada pada status siaga. Alexa, tombol BOOT, atau
perintah teks dari web STB yang diteruskan ke ESP32 dapat memulai sesi; musik
dijeda selama AI mendengar atau berbicara lalu dilanjutkan setelah state kembali
idle. TTS tak diminta dan notifikasi server saat musik aktif diabaikan.

Pemutar musik mendukung pencarian judul/penyanyi, menawarkan rekomendasi acak,
dan memutar kecocokan terbaik dari koleksi Navidrome. Katakan misalnya "cari
lagu [judul atau penyanyi]", "rekomendasikan lagu", atau "putar lagu [judul]".

Web DEMET AI disajikan oleh STB. ESP32 tidak lagi menyimpan atau menyajikan
halaman HTML; setelah tersambung ke jaringan, ESP32 tetap menyediakan
`GET /api/status`, `GET /api/search`, dan `POST /api/action` untuk kontrol
perangkat. Proxy STB meneruskan `/api/` ke ESP32.

Alamat proxy STB bawaan firmware adalah
`http://192.168.2.115:8097/stb-api`. Alamat lama backend langsung
`http://192.168.2.115:8095` dan `http://alofficial.local:8095` otomatis
dimasukkan ke alamat proxy web baru ketika pengaturan dimuat. Bila IP STB
berubah, simpan alamat baru dari menu tujuan musik pada website STB.

Web STB menyediakan slider volume musik dan volume AI secara terpisah. Relay dapat
didaftarkan hingga 14 GPIO kandidat yang diizinkan firmware; AI membaca nama
yang terdaftar melalui `self.relay.list` dan mengontrolnya memakai nama tersebut.
Perintah teks HP, tombol BOOT, dan wake word Alexa tetap dapat memulai AI saat
musik berjalan; musik dijeda selama sesi lalu dilanjutkan setelah AI siaga.

Ukuran layar yang diketahui adalah 128x32. Pengendali SSD1306 dan alamat I2C
`0x3C` masih asumsi yang perlu diperiksa pada modul atau skematik. Jika
pengendali/alamat berbeda, driver panel atau pengaturan alamat di implementasi
board perlu disesuaikan.

Sebelum memakai GPIO, pastikan pin tersebut tersedia dan tidak digunakan oleh
flash, PSRAM, USB, atau perangkat lain di versi board yang dimiliki. Periksa
diagram pin board terlebih dahulu; pastikan pemetaan ini sesuai dengan
perangkat keras.

## Memilih board dan melakukan build

Di menuconfig, pilih **DEMET AI ESP32-S3 N16R8 + OLED 0,91 inci (pemetaan GPIO
khusus)**. Alternatifnya, gunakan skrip `scripts/build.py` untuk melakukan build
varian `babu-ai`.

Profil ini belum mengatur pembacaan baterai, pengisian daya, atau GPIO sakelar
daya karena jalur-jalur tersebut belum diketahui.

## Arti pengaturan `config.json`

`config.json` berisi identitas dan pilihan build untuk skrip proyek. File JSON
tidak mendukung komentar, jadi penjelasan setiap kolom ditulis di sini:

| Kolom | Arti |
| --- | --- |
| `manufacturer` | Identitas pembuat/proyek yang dilaporkan firmware: `babu-ai`. |
| `type` | Identitas jenis board. Pertahankan nilai `babu-ai` agar cocok dengan pemetaan board firmware. |
| `target` | Keluarga chip ESP-IDF yang digunakan; `esp32s3` berarti ESP32-S3. |
| `builds` | Daftar varian firmware yang dapat dibuat untuk board ini. |
| `name` | Nama varian build, dalam hal ini `babu-ai`. |
| `sdkconfig_append` | Pengaturan tambahan khusus build. Daftar kosong berarti belum ada pengaturan tambahan. |

Nilai seperti `babu-ai` dan `esp32s3` adalah identifier yang dibaca alat build,
bukan keterangan untuk pengguna. Jangan menerjemahkannya atau mengubahnya
sembarangan.

## Volume dan jeda web

Volume AI dan musik diterapkan terpisah untuk setiap blok audio. Perintah jeda
dari API web STB dijadwalkan sesudah handler HTTP mengirim respons agar koneksi
kontrol tetap responsif.
