#ifndef NAVIDROME_PLAYER_H
#define NAVIDROME_PLAYER_H

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

#include "audio_service.h"

class NavidromePlayer {
public:
    NavidromePlayer(AudioService& audio_service, std::string base_url, std::string username,
                    std::string password);
    ~NavidromePlayer();

    bool IsConfigured() const;
    bool PlayRandom(bool wait_for_assistant_speech = false);
    bool PlayNext(bool wait_for_assistant_speech = false);
    bool PlaySong(const std::string& query, bool wait_for_assistant_speech = false);
    bool PlaySongById(const std::string& song_id, const std::string& title);
    std::string SearchSongs(const std::string& query);
    std::string SearchSongsJson(const std::string& query);
    std::string RecommendSongs();
    bool TogglePause();
    void Stop();
    std::string GetStatus() const;
    void OnAssistantSpeechStarted();
    void OnAssistantSpeechPlaybackDrained();
    void SetAssistantActive(bool active);
    void SetMusicVolume(int volume);
    void UpdateConfig(std::string base_url, std::string username, std::string password);
    std::string GetBaseUrl() const;
    std::string GetUsername() const;

private:
    AudioService& audio_service_;
    std::string base_url_;
    std::string username_;
    std::string password_;
    mutable std::mutex mutex_;
    std::condition_variable pause_cv_;
    TaskHandle_t task_handle_ = nullptr;
    uint32_t generation_ = 0;
    bool worker_running_ = false;
    bool request_pending_ = false;
    bool track_active_ = false;
    bool paused_ = false;
    bool continuous_playback_ = false;
    bool wait_for_assistant_speech_ = false;
    bool assistant_speech_started_ = false;
    bool assistant_speech_finished_ = false;
    bool assistant_active_ = false;
    bool assistant_paused_music_ = false;
    std::atomic<int> music_volume_{60};
    std::string last_track_id_;
    std::string pending_track_id_;
    std::string pending_track_title_;
    std::string current_title_;
    std::string status_ = "Navidrome belum dikonfigurasi";

    static void WorkerEntry(void* arg);
    void WorkerTask();
    bool RequestRandomTrack(bool wait_for_assistant_speech);
    bool RequestTrack(std::string song_id, std::string title, bool wait_for_assistant_speech,
                      bool continuous_playback);
    bool WaitForAssistantSpeech(uint32_t generation);
    bool IsCancelled(uint32_t generation) const;
    void SetStatus(uint32_t generation, const std::string& status);
    void ShowStatus(const std::string& status) const;
    bool BuildAuthQuery(std::string& query);
    bool GetRandomSong(uint32_t generation, const std::string& auth_query, std::string& song_id,
                       std::string& title);
    struct Track {
        std::string id;
        std::string title;
        std::string artist;
        std::string album;
    };
    bool FetchTracks(const std::string& endpoint, const std::string& query, size_t limit,
                     std::vector<Track>& tracks, const std::string& auth_query = {});
    bool StreamSong(uint32_t generation, const std::string& auth_query, const std::string& song_id,
                    const std::string& title);
};

#endif
