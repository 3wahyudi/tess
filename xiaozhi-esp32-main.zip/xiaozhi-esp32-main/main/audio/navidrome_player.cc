#include "navidrome_player.h"

#include <algorithm>
#include <array>
#include <cstring>
#include <memory>
#include <string_view>
#include <utility>

#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_random.h>
#include <mbedtls/md.h>

#include <esp_ae_rate_cvt.h>
#include <cJSON.h>
#include <decoder/impl/esp_mp3_dec.h>

#include "application.h"
#include "board.h"
#include "display/display.h"
#include "http.h"

namespace {
constexpr int kHttpTimeoutMs = 20000;
constexpr size_t kHttpReadBufferSize = 4096;
constexpr size_t kMusicPrebufferMs = 1200;
constexpr size_t kMaxBufferedMusicPlaybackTasks = 24;
constexpr size_t kMaxApiResponseSize = 16 * 1024;
constexpr size_t kMaxEncodedBufferSize = 64 * 1024;
constexpr size_t kMaxId3TagSize = 2 * 1024 * 1024;
constexpr size_t kInitialDecodedBufferSize = 8192;
constexpr size_t kMaxDecodedBufferSize = 16 * 1024;
constexpr auto kAssistantSpeechWaitTimeout = std::chrono::seconds(30);
constexpr uint32_t kPlaybackDrainWaitTimeoutMs = 5000;
constexpr uint32_t kPlayerTaskStackSize = 8192;
constexpr UBaseType_t kPlayerTaskPriority = 2;
constexpr char kTag[] = "Navidrome";

void LogHeapStats(const char* stage) {
    ESP_LOGI(kTag, "Heap %s: internal free=%u largest=%u minimum=%u, PSRAM free=%u", stage,
             static_cast<unsigned>(heap_caps_get_free_size(MALLOC_CAP_INTERNAL)),
             static_cast<unsigned>(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL)),
             static_cast<unsigned>(heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL)),
             static_cast<unsigned>(heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)));
}

bool IsHttpUrl(const std::string& url) {
    return url.compare(0, 7, "http://") == 0 || url.compare(0, 8, "https://") == 0;
}

std::string UrlEncode(std::string_view value) {
    static constexpr char kHex[] = "0123456789ABCDEF";
    std::string encoded;
    encoded.reserve(value.size());
    for (unsigned char ch : value) {
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') ||
            ch == '-' || ch == '_' || ch == '.' || ch == '~') {
            encoded.push_back(static_cast<char>(ch));
        } else {
            encoded.push_back('%');
            encoded.push_back(kHex[ch >> 4]);
            encoded.push_back(kHex[ch & 0x0F]);
        }
    }
    return encoded;
}

std::string ToHex(const uint8_t* bytes, size_t size) {
    static constexpr char kHex[] = "0123456789abcdef";
    std::string result(size * 2, '\0');
    for (size_t i = 0; i < size; ++i) {
        result[i * 2] = kHex[bytes[i] >> 4];
        result[i * 2 + 1] = kHex[bytes[i] & 0x0F];
    }
    return result;
}

bool ReadHttpBody(Http& http, size_t max_size, std::string& body) {
    std::vector<char> buffer(kHttpReadBufferSize);
    body.clear();
    while (true) {
        auto size = http.Read(buffer.data(), buffer.size());
        if (!size) {
            ESP_LOGE(kTag, "Navidrome HTTP read failed: %s", size.error().ToString().c_str());
            return false;
        }
        if (*size < 0) {
            ESP_LOGE(kTag, "Navidrome HTTP read returned an invalid size");
            return false;
        }
        if (*size == 0) {
            return true;
        }
        if (static_cast<size_t>(*size) > max_size - body.size()) {
            ESP_LOGE(kTag, "Navidrome API response exceeded %u bytes",
                     static_cast<unsigned>(max_size));
            return false;
        }
        body.append(buffer.data(), static_cast<size_t>(*size));
    }
}

bool GetId3TagSize(const uint8_t* header, size_t& total_size) {
    if (std::memcmp(header, "ID3", 3) != 0) {
        total_size = 0;
        return true;
    }
    if ((header[6] & 0x80) || (header[7] & 0x80) || (header[8] & 0x80) || (header[9] & 0x80)) {
        return false;
    }
    const size_t payload_size =
        (static_cast<size_t>(header[6]) << 21) | (static_cast<size_t>(header[7]) << 14) |
        (static_cast<size_t>(header[8]) << 7) | static_cast<size_t>(header[9]);
    total_size = payload_size + 10;
    return total_size <= kMaxId3TagSize;
}
}  // namespace

NavidromePlayer::NavidromePlayer(AudioService& audio_service, std::string base_url,
                                 std::string username, std::string password)
    : audio_service_(audio_service),
      base_url_(std::move(base_url)),
      username_(std::move(username)),
      password_(std::move(password)) {
    while (!base_url_.empty() && base_url_.back() == '/') {
        base_url_.pop_back();
    }
    status_ = IsConfigured() ? "Navidrome siap digunakan" : "Konfigurasi Navidrome belum lengkap";
}

NavidromePlayer::~NavidromePlayer() { Stop(); }

void NavidromePlayer::UpdateConfig(std::string base_url, std::string username,
                                   std::string password) {
    while (!base_url.empty() && base_url.back() == '/') {
        base_url.pop_back();
    }
    {
        std::lock_guard<std::mutex> lock(mutex_);
        base_url_ = std::move(base_url);
        username_ = std::move(username);
        password_ = std::move(password);
        status_ =
            IsConfigured() ? "Navidrome siap digunakan" : "Konfigurasi Navidrome belum lengkap";
    }
}

std::string NavidromePlayer::GetBaseUrl() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return base_url_;
}

std::string NavidromePlayer::GetUsername() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return username_;
}

bool NavidromePlayer::IsConfigured() const {
    return IsHttpUrl(base_url_) && !username_.empty() && !password_.empty();
}

bool NavidromePlayer::PlayRandom(bool wait_for_assistant_speech) {
    return RequestRandomTrack(wait_for_assistant_speech);
}

bool NavidromePlayer::PlayNext(bool wait_for_assistant_speech) {
    return RequestRandomTrack(wait_for_assistant_speech);
}

bool NavidromePlayer::PlaySong(const std::string& query, bool wait_for_assistant_speech) {
    std::vector<Track> tracks;
    if (!FetchTracks("search3", query, 5, tracks) || tracks.empty()) {
        std::string status = tracks.empty() ? "Lagu tidak ditemukan di koleksi Navidrome"
                                            : "Pencarian lagu gagal di Navidrome";
        {
            std::lock_guard<std::mutex> lock(mutex_);
            status_ = status;
        }
        ShowStatus(status);
        return false;
    }
    return RequestTrack(tracks.front().id, tracks.front().title, wait_for_assistant_speech, true);
}

bool NavidromePlayer::PlaySongById(const std::string& song_id, const std::string& title) {
    if (song_id.empty() || title.empty()) {
        return false;
    }
    return RequestTrack(song_id, title, false, true);
}

std::string NavidromePlayer::SearchSongsJson(const std::string& query) {
    std::vector<Track> tracks;
    if (!FetchTracks("search3", query, 10, tracks)) {
        return "[]";
    }
    cJSON* root = cJSON_CreateArray();
    if (root == nullptr) {
        return "[]";
    }
    for (const auto& track : tracks) {
        cJSON* item = cJSON_CreateObject();
        if (item == nullptr) {
            continue;
        }
        cJSON_AddStringToObject(item, "id", track.id.c_str());
        cJSON_AddStringToObject(item, "title", track.title.c_str());
        cJSON_AddStringToObject(item, "artist", track.artist.c_str());
        cJSON_AddStringToObject(item, "album", track.album.c_str());
        cJSON_AddItemToArray(root, item);
    }
    char* json = cJSON_PrintUnformatted(root);
    std::string result = json != nullptr ? json : "[]";
    cJSON_free(json);
    cJSON_Delete(root);
    return result;
}

std::string NavidromePlayer::SearchSongs(const std::string& query) {
    std::vector<Track> tracks;
    if (!FetchTracks("search3", query, 5, tracks)) {
        return "Pencarian lagu gagal. Periksa koneksi Navidrome.";
    }
    if (tracks.empty()) {
        return "Tidak ada lagu yang cocok di koleksi Navidrome.";
    }
    std::string result = "Hasil pencarian dari koleksi DEMET AI:";
    for (size_t i = 0; i < tracks.size(); ++i) {
        result += "\n" + std::to_string(i + 1) + ". " + tracks[i].title;
        if (!tracks[i].artist.empty()) {
            result += " — " + tracks[i].artist;
        }
        if (!tracks[i].album.empty()) {
            result += " (" + tracks[i].album + ")";
        }
    }
    return result;
}

std::string NavidromePlayer::RecommendSongs() {
    std::vector<Track> tracks;
    if (!FetchTracks("getRandomSongs", {}, 5, tracks)) {
        return "Rekomendasi lagu gagal dimuat dari Navidrome.";
    }
    if (tracks.empty()) {
        return "Belum ada lagu yang dapat direkomendasikan dari koleksi.";
    }
    std::string result = "Lagu yang bisa saya tawarkan dari koleksi DEMET AI:";
    for (size_t i = 0; i < tracks.size(); ++i) {
        result += "\n" + std::to_string(i + 1) + ". " + tracks[i].title;
        if (!tracks[i].artist.empty()) {
            result += " — " + tracks[i].artist;
        }
    }
    return result;
}

void NavidromePlayer::Stop() {
    std::string status;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        ++generation_;
        request_pending_ = false;
        track_active_ = false;
        paused_ = false;
        continuous_playback_ = false;
        current_title_.clear();
        status_ = "Musik dihentikan";
        status = status_;
        audio_service_.ResetDecoder();
        assistant_speech_started_ = false;
        assistant_speech_finished_ = false;
        Application::GetInstance().SetLocalMediaPlaybackActive(false);
        pause_cv_.notify_all();
    }
    audio_service_.SetMusicPlaybackPaused(false);
    ShowStatus(status);
}

bool NavidromePlayer::TogglePause() {
    bool start_random_track = false;
    bool media_active = false;
    bool media_state_changed = false;
    bool pause_music_output = false;
    std::string status;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (assistant_active_ && track_active_) {
            status_ = "Musik dijeda selama AI aktif";
            status = status_;
        } else if (continuous_playback_ || track_active_) {
            paused_ = !paused_;
            assistant_paused_music_ = false;
            pause_music_output = paused_;
            media_active = track_active_ && !paused_;
            media_state_changed = true;
            if (paused_) {
                status_ = current_title_.empty() ? "Musik dijeda" : "Dijeda: " + current_title_;
            } else if (track_active_ && !current_title_.empty()) {
                status_ = "Memutar: " + current_title_;
            } else if (worker_running_) {
                status_ = "Melanjutkan pemutaran musik";
            } else {
                start_random_track = true;
            }
            status = status_;
        } else if (worker_running_) {
            status_ = "Lagu sedang disiapkan";
            status = status_;
        } else {
            start_random_track = true;
        }
    }

    if (media_state_changed) {
        audio_service_.SetMusicPlaybackPaused(pause_music_output);
    }
    if (media_state_changed) {
        Application::GetInstance().SetLocalMediaPlaybackActive(media_active);
    }
    if (start_random_track) {
        return PlayRandom();
    }

    pause_cv_.notify_all();
    ShowStatus(status);
    return true;
}

void NavidromePlayer::SetAssistantActive(bool active) {
    bool media_active = false;
    bool pause_music_output = false;
    bool music_pause_changed = false;
    std::string status;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        assistant_active_ = active;
        if (active) {
            if (track_active_ && !paused_) {
                paused_ = true;
                assistant_paused_music_ = true;
                pause_music_output = true;
                music_pause_changed = true;
                status_ = current_title_.empty() ? "Musik dijeda untuk AI"
                                                 : "Dijeda untuk AI: " + current_title_;
                status = status_;
            }
        } else if (assistant_paused_music_) {
            assistant_paused_music_ = false;
            paused_ = false;
            music_pause_changed = true;
            media_active = track_active_;
            status_ = current_title_.empty() ? "Melanjutkan musik" : "Memutar: " + current_title_;
            status = status_;
        }
    }

    if (music_pause_changed) {
        audio_service_.SetMusicPlaybackPaused(pause_music_output,
                                              active && pause_music_output);
    }
    if (!status.empty()) {
        Application::GetInstance().SetLocalMediaPlaybackActive(media_active);
        pause_cv_.notify_all();
        ShowStatus(status);
    }
}

void NavidromePlayer::SetMusicVolume(int volume) {
    music_volume_.store(std::clamp(volume, 0, 100), std::memory_order_relaxed);
}

std::string NavidromePlayer::GetStatus() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return status_;
}

bool NavidromePlayer::RequestRandomTrack(bool wait_for_assistant_speech) {
    return RequestTrack({}, {}, wait_for_assistant_speech, true);
}

bool NavidromePlayer::RequestTrack(std::string song_id, std::string title,
                                   bool wait_for_assistant_speech, bool continuous_playback) {
    if (!IsConfigured()) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            status_ = "Konfigurasi Navidrome belum lengkap";
        }
        ShowStatus("Konfigurasi Navidrome belum lengkap");
        return false;
    }

    std::unique_lock<std::mutex> lock(mutex_);
    ++generation_;
    request_pending_ = true;
    pending_track_id_ = std::move(song_id);
    pending_track_title_ = std::move(title);
    track_active_ = false;
    paused_ = false;
    continuous_playback_ = continuous_playback;
    wait_for_assistant_speech_ = wait_for_assistant_speech;
    assistant_speech_started_ = wait_for_assistant_speech &&
                                Application::GetInstance().GetDeviceState() == kDeviceStateSpeaking;
    assistant_speech_finished_ = false;
    current_title_.clear();
    status_ = "Menghubungkan ke Navidrome";
    audio_service_.SetMusicPlaybackPaused(false);
    if (!wait_for_assistant_speech) {
        audio_service_.ResetDecoder();
    }
    pause_cv_.notify_all();
    if (worker_running_) {
        return true;
    }

    worker_running_ = true;
    if (xTaskCreate(WorkerEntry, "navidrome", kPlayerTaskStackSize, this, kPlayerTaskPriority,
                    &task_handle_) != pdPASS) {
        worker_running_ = false;
        request_pending_ = false;
        task_handle_ = nullptr;
        status_ = "Gagal membuat task pemutar musik";
        ESP_LOGE(kTag, "Failed to create Navidrome worker task");
        const std::string status = status_;
        lock.unlock();
        ShowStatus(status);
        return false;
    }
    return true;
}

bool NavidromePlayer::IsCancelled(uint32_t generation) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return generation_ != generation;
}

void NavidromePlayer::OnAssistantSpeechStarted() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (wait_for_assistant_speech_ && (worker_running_ || request_pending_)) {
        assistant_speech_started_ = true;
        assistant_speech_finished_ = false;
    }
}

void NavidromePlayer::OnAssistantSpeechPlaybackDrained() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!wait_for_assistant_speech_ || !assistant_speech_started_) {
            return;
        }
        assistant_speech_finished_ = true;
    }
    pause_cv_.notify_all();
}

bool NavidromePlayer::WaitForAssistantSpeech(uint32_t generation) {
    std::unique_lock<std::mutex> lock(mutex_);
    if (generation_ != generation || !wait_for_assistant_speech_) {
        return generation_ == generation;
    }

    const bool speech_finished =
        pause_cv_.wait_for(lock, kAssistantSpeechWaitTimeout, [this, generation]() {
            return generation_ != generation ||
                   (assistant_speech_started_ && assistant_speech_finished_);
        });
    if (generation_ != generation) {
        return false;
    }
    if (!speech_finished) {
        status_ = "Ucapan AI belum selesai; musik tidak dimulai";
        const std::string status = status_;
        lock.unlock();
        ShowStatus(status);
        ESP_LOGW(kTag, "Cancelled music start because assistant speech did not finish in time");
        return false;
    }
    wait_for_assistant_speech_ = false;
    assistant_speech_started_ = false;
    assistant_speech_finished_ = false;
    return true;
}

void NavidromePlayer::SetStatus(uint32_t generation, const std::string& status) {
    bool updated = false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (generation_ == generation) {
            status_ = status;
            updated = true;
        }
    }
    if (updated) {
        ShowStatus(status);
    }
}

void NavidromePlayer::ShowStatus(const std::string& status) const {
    Application::GetInstance().Schedule([status]() {
        auto* display = Board::GetInstance().GetDisplay();
        if (display != nullptr) {
            display->SetChatMessage("system", status.c_str());
        }
    });
}

void NavidromePlayer::WorkerEntry(void* arg) {
    auto* player = static_cast<NavidromePlayer*>(arg);
    player->WorkerTask();
    vTaskDelete(nullptr);
}

void NavidromePlayer::WorkerTask() {
    while (true) {
        uint32_t generation = 0;
        bool wait_for_assistant_speech = false;
        std::string selected_song_id;
        std::string selected_title;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (!request_pending_) {
                worker_running_ = false;
                task_handle_ = nullptr;
                return;
            }
            request_pending_ = false;
            generation = generation_;
            wait_for_assistant_speech = wait_for_assistant_speech_;
            selected_song_id = std::move(pending_track_id_);
            selected_title = std::move(pending_track_title_);
        }

        std::string song_id;
        std::string title;
        std::string auth_query;
        bool success = BuildAuthQuery(auth_query);
        if (success && !selected_song_id.empty()) {
            song_id = std::move(selected_song_id);
            title = std::move(selected_title);
        } else if (success) {
            success = GetRandomSong(generation, auth_query, song_id, title);
        }
        if (success && !IsCancelled(generation)) {
            {
                std::lock_guard<std::mutex> lock(mutex_);
                if (generation_ == generation) {
                    last_track_id_ = song_id;
                }
            }
            if (wait_for_assistant_speech) {
                SetStatus(generation, "Menunggu ucapan AI selesai: " + title);
                success = WaitForAssistantSpeech(generation);
            }
            if (success && !IsCancelled(generation)) {
                bool media_mode_started = false;
                {
                    std::unique_lock<std::mutex> lock(mutex_);
                    pause_cv_.wait(lock, [this, generation]() {
                        return generation_ != generation || !paused_;
                    });
                    if (generation_ == generation) {
                        media_mode_started = true;
                    }
                }
                if (!media_mode_started) {
                    success = false;
                } else {
                    Application::GetInstance().SetLocalMediaPlaybackActive(true);
                    success = StreamSong(generation, auth_query, song_id, title);
                }
            }
        }
        if (!success) {
            bool needs_fallback_status = false;
            bool clear_media_mode = false;
            {
                std::lock_guard<std::mutex> lock(mutex_);
                if (generation_ == generation) {
                    clear_media_mode = true;
                    continuous_playback_ = false;
                    paused_ = false;
                    needs_fallback_status = status_ == "Menghubungkan ke Navidrome";
                }
            }
            if (clear_media_mode) {
                Application::GetInstance().SetLocalMediaPlaybackActive(false);
            }
            if (needs_fallback_status && !IsCancelled(generation)) {
                SetStatus(generation, "Pemutaran gagal; periksa koneksi, akun, atau log perangkat");
            }
        }
    }
}

bool NavidromePlayer::BuildAuthQuery(std::string& query) {
    std::array<uint8_t, 8> random_salt{};
    esp_fill_random(random_salt.data(), random_salt.size());
    const std::string salt = ToHex(random_salt.data(), random_salt.size());
    const std::string input = password_ + salt;
    std::array<uint8_t, 16> digest{};
    const mbedtls_md_info_t* md_info = mbedtls_md_info_from_type(MBEDTLS_MD_MD5);
    if (md_info == nullptr) {
        ESP_LOGE(kTag, "MD5 support is unavailable");
        return false;
    }
    const int result = mbedtls_md(md_info, reinterpret_cast<const unsigned char*>(input.data()),
                                  input.size(), digest.data());
    if (result != 0) {
        ESP_LOGE(kTag, "Failed to generate Navidrome authentication token: %d", result);
        return false;
    }

    query = "u=" + UrlEncode(username_) + "&t=" + ToHex(digest.data(), digest.size()) +
            "&s=" + salt + "&v=1.16.1&c=babu-ai&f=json";
    return true;
}

bool NavidromePlayer::GetRandomSong(uint32_t generation, const std::string& auth_query,
                                    std::string& song_id, std::string& title) {
    std::string previous_track_id;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        previous_track_id = last_track_id_;
    }

    std::vector<Track> tracks;
    const bool fetched = FetchTracks("getRandomSongs", {}, 10, tracks, auth_query);
    bool success = false;
    for (const auto& track : tracks) {
        if (track.id != previous_track_id) {
            song_id = track.id;
            title = track.title;
            success = true;
            break;
        }
    }
    if (!success && !IsCancelled(generation)) {
        ESP_LOGE(kTag, "Navidrome did not return a song different from the previous track%s",
                 fetched ? "" : " or the API request failed");
        SetStatus(generation, previous_track_id.empty()
                                  ? "Tidak ada lagu dari Navidrome atau akun ditolak"
                                  : "Tidak ada lagu berbeda dari lagu terakhir di Navidrome");
    }
    return success;
}

bool NavidromePlayer::FetchTracks(const std::string& endpoint, const std::string& query,
                                  size_t limit, std::vector<Track>& tracks,
                                  const std::string& supplied_auth_query) {
    tracks.clear();
    if (!IsConfigured() || limit == 0 || limit > 10 || query.size() > 120 ||
        (endpoint == "search3" && query.empty())) {
        return false;
    }

    std::string auth_query = supplied_auth_query;
    if (auth_query.empty() && !BuildAuthQuery(auth_query)) {
        return false;
    }
    auto* network = Board::GetInstance().GetNetwork();
    if (network == nullptr) {
        ESP_LOGE(kTag, "Network interface is unavailable");
        return false;
    }
    auto http = network->CreateHttp(0);
    if (!http) {
        ESP_LOGE(kTag, "Failed to create Navidrome search HTTP client");
        return false;
    }
    http->SetTimeout(kHttpTimeoutMs);
    http->SetHeader("Accept", "application/json");
    std::string url = base_url_ + "/rest/" + endpoint + ".view?" + auth_query;
    if (endpoint == "search3") {
        url += "&query=" + UrlEncode(query) + "&songCount=" + std::to_string(limit) +
               "&albumCount=0&artistCount=0";
    } else if (endpoint == "getRandomSongs") {
        url += "&size=" + std::to_string(limit);
    } else {
        http->Close();
        return false;
    }

    bool success = false;
    auto opened = http->Open("GET", url);
    if (!opened) {
        ESP_LOGE(kTag, "Failed to open Navidrome API request: %s",
                 opened.error().ToString().c_str());
    } else {
        auto status = http->GetStatusCode();
        if (!status || *status < 200 || *status >= 300) {
            ESP_LOGE(kTag, "Navidrome API returned an invalid HTTP status");
        } else {
            std::string body;
            if (ReadHttpBody(*http, kMaxApiResponseSize, body)) {
                std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(cJSON_Parse(body.c_str()),
                                                                     cJSON_Delete);
                cJSON* response =
                    root ? cJSON_GetObjectItemCaseSensitive(root.get(), "subsonic-response")
                         : nullptr;
                cJSON* api_error =
                    response ? cJSON_GetObjectItemCaseSensitive(response, "error") : nullptr;
                if (api_error != nullptr) {
                    cJSON* message = cJSON_GetObjectItemCaseSensitive(api_error, "message");
                    ESP_LOGE(kTag, "Navidrome API error: %s",
                             cJSON_IsString(message) ? message->valuestring : "unknown error");
                } else {
                    const char* result_name =
                        endpoint == "search3" ? "searchResult3" : "randomSongs";
                    cJSON* result = response
                                        ? cJSON_GetObjectItemCaseSensitive(response, result_name)
                                        : nullptr;
                    cJSON* song_list =
                        result ? cJSON_GetObjectItemCaseSensitive(result, "song") : nullptr;
                    const auto append_track = [&tracks](cJSON* song) {
                        cJSON* id = song ? cJSON_GetObjectItemCaseSensitive(song, "id") : nullptr;
                        cJSON* title =
                            song ? cJSON_GetObjectItemCaseSensitive(song, "title") : nullptr;
                        if (!cJSON_IsString(id) || id->valuestring == nullptr ||
                            id->valuestring[0] == '\0' || !cJSON_IsString(title) ||
                            title->valuestring == nullptr) {
                            return;
                        }
                        Track track;
                        track.id = id->valuestring;
                        track.title = title->valuestring;
                        cJSON* artist = cJSON_GetObjectItemCaseSensitive(song, "artist");
                        cJSON* album = cJSON_GetObjectItemCaseSensitive(song, "album");
                        if (cJSON_IsString(artist) && artist->valuestring != nullptr) {
                            track.artist = artist->valuestring;
                        }
                        if (cJSON_IsString(album) && album->valuestring != nullptr) {
                            track.album = album->valuestring;
                        }
                        tracks.push_back(std::move(track));
                    };
                    if (cJSON_IsArray(song_list)) {
                        cJSON* song = nullptr;
                        cJSON_ArrayForEach (song, song_list) {
                            if (tracks.size() >= limit) {
                                break;
                            }
                            append_track(song);
                        }
                    } else if (song_list != nullptr) {
                        append_track(song_list);
                    }
                    success = true;
                }
            }
        }
    }
    http->Close();
    return success;
}

bool NavidromePlayer::StreamSong(uint32_t generation, const std::string& auth_query,
                                 const std::string& song_id, const std::string& title) {
    auto* network = Board::GetInstance().GetNetwork();
    if (network == nullptr) {
        ESP_LOGE(kTag, "Network interface is unavailable");
        SetStatus(generation, "Jaringan tidak tersedia");
        return false;
    }
    auto* codec = Board::GetInstance().GetAudioCodec();
    if (codec == nullptr || (codec->output_channels() != 1 && codec->output_channels() != 2)) {
        ESP_LOGE(kTag, "Navidrome playback requires a mono or stereo output codec");
        SetStatus(generation, "Format speaker tidak didukung");
        return false;
    }

    auto http = network->CreateHttp(0);
    if (!http) {
        ESP_LOGE(kTag, "Failed to create Navidrome stream HTTP client");
        SetStatus(generation, "Gagal membuat koneksi stream musik");
        return false;
    }
    http->SetTimeout(kHttpTimeoutMs);
    http->SetHeader("Accept", "audio/mpeg, audio/*");
    http->SetHeader("Accept-Encoding", "identity");
    const std::string url =
        base_url_ + "/rest/stream.view?" + auth_query + "&id=" + UrlEncode(song_id) + "&format=mp3";
    auto opened = http->Open("GET", url);
    if (!opened) {
        ESP_LOGE(kTag, "Failed to open Navidrome stream: %s", opened.error().ToString().c_str());
        SetStatus(generation, "Gagal membuka stream Navidrome");
        http->Close();
        return false;
    }
    auto status = http->GetStatusCode();
    if (!status || *status < 200 || *status >= 300) {
        if (!status) {
            ESP_LOGE(kTag, "Navidrome stream status failed: %s", status.error().ToString().c_str());
        } else {
            ESP_LOGE(kTag, "Navidrome stream returned HTTP %d", *status);
        }
        SetStatus(generation, "Server menolak stream musik");
        http->Close();
        return false;
    }

    void* decoder = nullptr;
    if (esp_mp3_dec_open(nullptr, 0, &decoder) != ESP_AUDIO_ERR_OK) {
        ESP_LOGE(kTag, "Failed to open MP3 decoder");
        SetStatus(generation, "Gagal membuka decoder MP3");
        http->Close();
        return false;
    }

    audio_service_.ResetDecoder();
    LogHeapStats("sebelum pemutaran Navidrome");
    bool request_is_current = false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (generation_ == generation) {
            current_title_ = title;
            track_active_ = true;
            request_is_current = true;
        }
    }
    if (!request_is_current) {
        esp_mp3_dec_close(decoder);
        http->Close();
        return false;
    }
    SetStatus(generation, "Memutar: " + title);
    ESP_LOGI(kTag, "Streaming Navidrome track: %s", title.c_str());

    bool success = false;
    bool id3_header_checked = false;
    size_t id3_skip_remaining = 0;
    size_t decoded_frames = 0;
    std::array<uint8_t, 10> id3_header{};
    size_t id3_header_size = 0;
    std::vector<uint8_t> encoded_buffer;
    encoded_buffer.reserve(4096);
    std::vector<uint8_t> decoded_buffer(kInitialDecodedBufferSize);
    esp_ae_rate_cvt_handle_t resampler = nullptr;
    int resampler_source_rate = 0;
    const int target_rate = codec->output_sample_rate();
    const int target_channels = codec->output_channels();
    const size_t prebuffer_target_samples =
        static_cast<size_t>(target_rate) * kMusicPrebufferMs / 1000;
    std::vector<std::vector<int16_t>> prebuffer;
    size_t prebuffered_samples = 0;
    bool playback_started = false;

    auto push_pcm = [&](std::vector<int16_t>&& pcm) -> bool {
        std::unique_lock<std::mutex> lock(mutex_);
        pause_cv_.wait(lock, [this, generation]() {
            return generation_ != generation || !paused_;
        });
        if (generation_ != generation) {
            return false;
        }
        lock.unlock();

        if (!audio_service_.PushPcmToPlaybackQueue(std::move(pcm), true,
                                                   kMaxBufferedMusicPlaybackTasks,
                                                   music_volume_.load(std::memory_order_relaxed))) {
            return false;
        }
        if (IsCancelled(generation)) {
            audio_service_.ResetDecoder();
            return false;
        }
        return true;
    };

    auto flush_prebuffer = [&]() -> bool {
        for (auto& frame : prebuffer) {
            if (!push_pcm(std::move(frame))) {
                return false;
            }
        }
        prebuffer.clear();
        prebuffered_samples = 0;
        playback_started = true;
        return true;
    };

    auto queue_decoded_frame = [&](const uint8_t* data, size_t byte_count,
                                   const esp_audio_dec_info_t& info) -> bool {
        if (byte_count == 0 || IsCancelled(generation)) {
            return byte_count == 0;
        }
        if (info.bits_per_sample != ESP_AUDIO_BIT16 || info.sample_rate == 0 ||
            (info.channel != 1 && info.channel != 2) || target_rate <= 0) {
            ESP_LOGE(kTag, "Unsupported MP3 format: %u Hz, %u-bit, %u channel",
                     static_cast<unsigned>(info.sample_rate),
                     static_cast<unsigned>(info.bits_per_sample),
                     static_cast<unsigned>(info.channel));
            return false;
        }

        const size_t input_samples = byte_count / sizeof(int16_t) / info.channel;
        if (input_samples == 0 || byte_count % (sizeof(int16_t) * info.channel) != 0) {
            ESP_LOGE(kTag, "MP3 decoder returned an invalid PCM frame size");
            return false;
        }
        const auto* input = reinterpret_cast<const int16_t*>(data);
        std::vector<int16_t> formatted(input_samples * target_channels);
        if (info.channel == target_channels) {
            std::copy(input, input + formatted.size(), formatted.begin());
        } else if (info.channel == 2 && target_channels == 1) {
            for (size_t i = 0; i < input_samples; ++i) {
                const int32_t sum = static_cast<int32_t>(input[i * 2]) + input[i * 2 + 1];
                formatted[i] = static_cast<int16_t>(sum / 2);
            }
        } else {
            for (size_t i = 0; i < input_samples; ++i) {
                formatted[i * 2] = input[i];
                formatted[i * 2 + 1] = input[i];
            }
        }

        if (info.sample_rate != target_rate) {
            if (resampler == nullptr ||
                resampler_source_rate != static_cast<int>(info.sample_rate)) {
                if (resampler != nullptr) {
                    esp_ae_rate_cvt_close(resampler);
                    resampler = nullptr;
                }
                esp_ae_rate_cvt_cfg_t config = {
                    .src_rate = info.sample_rate,
                    .dest_rate = static_cast<uint32_t>(target_rate),
                    .channel = static_cast<uint8_t>(target_channels),
                    .bits_per_sample = ESP_AUDIO_BIT16,
                    .complexity = 2,
                    .perf_type = ESP_AE_RATE_CVT_PERF_TYPE_SPEED,
                };
                if (esp_ae_rate_cvt_open(&config, &resampler) != ESP_AE_ERR_OK ||
                    resampler == nullptr) {
                    ESP_LOGE(kTag, "Failed to create MP3 sample-rate converter");
                    return false;
                }
                resampler_source_rate = info.sample_rate;
            }

            uint32_t max_output_samples = 0;
            if (esp_ae_rate_cvt_get_max_out_sample_num(resampler,
                                                       static_cast<uint32_t>(input_samples),
                                                       &max_output_samples) != ESP_AE_ERR_OK) {
                ESP_LOGE(kTag, "Failed to size resampled MP3 frame");
                return false;
            }
            std::vector<int16_t> resampled(static_cast<size_t>(max_output_samples) *
                                           target_channels);
            uint32_t actual_output_samples = max_output_samples;
            if (esp_ae_rate_cvt_process(resampler, formatted.data(),
                                        static_cast<uint32_t>(input_samples), resampled.data(),
                                        &actual_output_samples) != ESP_AE_ERR_OK) {
                ESP_LOGE(kTag, "Failed to resample MP3 audio");
                return false;
            }
            resampled.resize(static_cast<size_t>(actual_output_samples) * target_channels);
            formatted = std::move(resampled);
        }

        if (formatted.empty() || IsCancelled(generation)) {
            return !IsCancelled(generation);
        }
        ++decoded_frames;
        if (!playback_started) {
            prebuffered_samples += formatted.size() / target_channels;
            prebuffer.push_back(std::move(formatted));
            if (prebuffered_samples < prebuffer_target_samples) {
                return true;
            }
            return flush_prebuffer();
        }
        return push_pcm(std::move(formatted));
    };

    auto decode_pending = [&]() -> bool {
        while (!encoded_buffer.empty() && !IsCancelled(generation)) {
            if (encoded_buffer.size() >= 3 && std::memcmp(encoded_buffer.data(), "TAG", 3) == 0) {
                if (encoded_buffer.size() < 128) {
                    break;
                }
                if (encoded_buffer.size() == 128) {
                    encoded_buffer.clear();
                    break;
                }
                ESP_LOGE(kTag, "Invalid ID3v1 tag at the end of MP3 stream");
                return false;
            }
            esp_audio_dec_in_raw_t raw = {
                .buffer = encoded_buffer.data(),
                .len = static_cast<uint32_t>(encoded_buffer.size()),
            };
            esp_audio_dec_out_frame_t frame = {
                .buffer = decoded_buffer.data(),
                .len = static_cast<uint32_t>(decoded_buffer.size()),
            };
            esp_audio_dec_info_t info = {};
            const auto result = esp_mp3_dec_decode(decoder, &raw, &frame, &info);
            if (raw.consumed > encoded_buffer.size()) {
                ESP_LOGE(kTag, "MP3 decoder consumed more data than supplied");
                return false;
            }
            if (raw.consumed > 0) {
                encoded_buffer.erase(encoded_buffer.begin(), encoded_buffer.begin() + raw.consumed);
            }
            if (frame.decoded_size > 0 &&
                !queue_decoded_frame(frame.buffer, frame.decoded_size, info)) {
                return false;
            }
            if (result == ESP_AUDIO_ERR_BUFF_NOT_ENOUGH) {
                if (frame.needed_size <= decoded_buffer.size() ||
                    frame.needed_size > kMaxDecodedBufferSize) {
                    ESP_LOGE(kTag, "MP3 decoder requested an invalid output buffer size");
                    return false;
                }
                decoded_buffer.resize(frame.needed_size);
                continue;
            }
            if (result == ESP_AUDIO_ERR_DATA_LACK) {
                if (raw.consumed == 0) {
                    break;
                }
                continue;
            }
            if (result != ESP_AUDIO_ERR_OK) {
                ESP_LOGE(kTag, "MP3 decode failed with error %d", result);
                return false;
            }
            if (raw.consumed == 0 && frame.decoded_size == 0) {
                break;
            }
        }
        return !IsCancelled(generation);
    };

    std::vector<char> read_buffer(kHttpReadBufferSize);
    while (!IsCancelled(generation)) {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            pause_cv_.wait(lock, [this, generation]() {
                return generation_ != generation || !paused_;
            });
            if (generation_ != generation) {
                break;
            }
        }
        auto size = http->Read(read_buffer.data(), read_buffer.size());
        if (!size) {
            ESP_LOGE(kTag, "Navidrome stream read failed: %s", size.error().ToString().c_str());
            break;
        }
        if (*size < 0) {
            ESP_LOGE(kTag, "Navidrome stream read returned an invalid size");
            break;
        }
        if (*size == 0) {
            if (id3_header_size != 0 && !id3_header_checked) {
                ESP_LOGE(kTag, "MP3 stream ended inside its ID3 header");
                break;
            }
            if (id3_skip_remaining > 0) {
                ESP_LOGE(kTag, "MP3 stream ended inside its ID3 tag");
                break;
            }
            if (encoded_buffer.size() >= 3 && std::memcmp(encoded_buffer.data(), "TAG", 3) == 0 &&
                encoded_buffer.size() <= 128) {
                encoded_buffer.clear();
            }
            if (encoded_buffer.size() > 3 || !decode_pending()) {
                ESP_LOGE(kTag, "MP3 stream ended with incomplete frame data");
                break;
            }
            if (!flush_prebuffer()) {
                break;
            }
            success = decoded_frames > 0;
            break;
        }

        const uint8_t* input = reinterpret_cast<const uint8_t*>(read_buffer.data());
        size_t input_size = *size;
        if (!id3_header_checked) {
            const size_t copy_size = std::min(input_size, id3_header.size() - id3_header_size);
            std::memcpy(id3_header.data() + id3_header_size, input, copy_size);
            id3_header_size += copy_size;
            input += copy_size;
            input_size -= copy_size;
            if (id3_header_size < id3_header.size()) {
                continue;
            }
            size_t tag_size = 0;
            if (!GetId3TagSize(id3_header.data(), tag_size)) {
                ESP_LOGE(kTag, "Invalid or oversized ID3 tag in MP3 stream");
                break;
            }
            id3_header_checked = true;
            if (tag_size == 0) {
                encoded_buffer.insert(encoded_buffer.end(), id3_header.begin(), id3_header.end());
            } else {
                id3_skip_remaining = tag_size - id3_header.size();
            }
        }
        if (id3_skip_remaining > 0) {
            const size_t skipped = std::min(input_size, id3_skip_remaining);
            input += skipped;
            input_size -= skipped;
            id3_skip_remaining -= skipped;
        }
        if (input_size > 0) {
            encoded_buffer.insert(encoded_buffer.end(), input, input + input_size);
        }
        if (encoded_buffer.size() > kMaxEncodedBufferSize || !decode_pending()) {
            ESP_LOGE(kTag, "Failed while decoding Navidrome MP3 stream");
            break;
        }
    }

    if (resampler != nullptr) {
        esp_ae_rate_cvt_close(resampler);
    }
    esp_mp3_dec_close(decoder);
    http->Close();

    if (IsCancelled(generation)) {
        return false;
    }

    const TickType_t drain_deadline =
        xTaskGetTickCount() + pdMS_TO_TICKS(kPlaybackDrainWaitTimeoutMs);
    while (!IsCancelled(generation) && !audio_service_.IsPlaybackIdle() &&
           static_cast<int32_t>(drain_deadline - xTaskGetTickCount()) > 0) {
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    if (!audio_service_.IsPlaybackIdle() && !IsCancelled(generation)) {
        ESP_LOGW(kTag, "Playback queue did not drain before its timeout");
        audio_service_.ResetDecoder();
    }

    if (IsCancelled(generation)) {
        return false;
    }

    std::string final_status;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (generation_ == generation) {
            track_active_ = false;
            if (success) {
                last_track_id_ = song_id;
                if (continuous_playback_ && !paused_) {
                    request_pending_ = true;
                    status_ = "Lagu selesai; menyiapkan lagu berikutnya";
                } else if (paused_) {
                    status_ = current_title_.empty() ? "Musik dijeda" : "Dijeda: " + title;
                    Application::GetInstance().SetLocalMediaPlaybackActive(false);
                    pending_track_id_ = song_id;
                    pending_track_title_ = title;
                    request_pending_ = true;
                } else {
                    continuous_playback_ = false;
                    status_ = "Selesai: " + title;
                    Application::GetInstance().SetLocalMediaPlaybackActive(false);
                }
            } else {
                Application::GetInstance().SetLocalMediaPlaybackActive(false);
                current_title_.clear();
                status_ = "Stream MP3 gagal atau tidak berisi audio yang dapat diputar";
            }
            final_status = status_;
        }
    }
    LogHeapStats("setelah pemutaran Navidrome");
    if (success) {
        ESP_LOGI(kTag, "Finished Navidrome track: %s", title.c_str());
    }
    if (!final_status.empty()) {
        ShowStatus(final_status);
    }
    return success;
}
